#inciud<bits/stdc++.h>
using namespace std;
int main(){
	freopen("migrate.in","r",stdin);
	freopen("migrate.out","w",stdout);
	
	
	
	
	
	
	
	
	cout<<1<<endl<<2;
	return 0;
}
