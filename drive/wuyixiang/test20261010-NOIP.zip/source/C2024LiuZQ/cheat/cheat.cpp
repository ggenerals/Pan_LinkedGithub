#include <bits/stdc++.h>
using namespace std;
using ll = long long;
const int MOD = 998244353;
struct p{
    int id, v, w;
};
vector<p> vc[200005];
struct pqz{
    int id, dis;
    bool operator < (const pqz &a) const{
        return a.dis < dis;
    }
};
int n, m, q, x, dis[200005];
bool f[200005];
void Dijk(int s, int t){
    priority_queue<pqz> pq;
    memset(dis, 0x3f, sizeof dis);
    memset(f, 0, sizeof f);
    dis[s] = 0;
    pq.push({s, 0});
    while(!pq.empty()){
        int fr = pq.top().id; pq.pop();
        if(f[fr]) continue;
        f[fr] = 1;
        for(auto i : vc[fr]){
            if(i.id == x) continue;
            if(dis[i.v] <= dis[fr] + i.w) continue;
            dis[i.v] = dis[fr] + i.w;
            pq.push({i.v, dis[i.v]});
        }
    }
}
int main(){
    freopen("cheat.in", "r", stdin);
    freopen("cheat.out", "w", stdout);
    ios::sync_with_stdio(0);
    cin.tie(0);
    cin >> n >> m;
    for(int i = 1; i <= m; i++){
        int l, r;
        cin >> l >> r;
        vc[l].push_back({i, r, 1});
    }
    for(int i = 1; i <= n - 1; i++) vc[i + 1].push_back({n + i, i, 0});
    cin >> q;
    while(q--){
        int s, t;
        cin >> x >> s >> t;
        Dijk(s, t);
        if(dis[t] > 1e9) dis[t] = -1;
        cout << dis[t] << '\n';
    }
    return 0;
}
