#include <bits/stdc++.h>
using namespace std;
using ll = long long;
const int MOD = 998244353;
int n, m;
ll ans1, ans2, pw[10000005], inv[10000005];
bool p[25];
void dfs(int x){
    if(x > n){
        int l = 0, a = 0, fl = 0;
        for(int i = 1; i <= n; i++){
            if(p[i]) l++;
            else{
                if(l >= m){
                    a = 1;
                    if(l == m) fl++;
                }
                l = 0;
            }
        }
        if(l >= m){
            a = 1;
            if(l == m) fl++;
        }
        if(a) ans1++;
        if(fl == 1) ans2++;
        return;
    }
    p[x] = 1;
    dfs(x + 1);
    p[x] = 0;
    dfs(x + 1);
}
ll fstp(ll x, int y = MOD - 2){
    ll ans = 1;
    while(y){
        if(y & 1) ans = ans * x % MOD;
        x = x * x % MOD;
        y >>= 1;
    }
    return ans;
}
void init(){
    pw[0] = 1;
    for(int i = 1; i <= n; i++) pw[i] = pw[i - 1] * i % MOD;
    inv[n] = fstp(pw[n]);
    for(int i = n; i >= 1; i--) inv[i - 1] = inv[i] * i % MOD;
}
ll C(int x, int y){
    return pw[y] * inv[y - x] % MOD * inv[x] % MOD;
}
int main(){
    freopen("seiran.in", "r", stdin);
    freopen("seiran.out", "w", stdout);
    ios::sync_with_stdio(0);
    cin.tie(0);
    cin >> n >> m;
    if(n <= 20){
        dfs(1);
        cout << ans1 << '\n' << ans2;
        return 0;
    }
    init();
    if(m == 1){
        cout << (fstp(2ll, n) - 1) % MOD << '\n' << n;
        return 0;
    }
    for(int i = 0; i <= n - m; i++){
        ans1 += C(i, n - m) * (n - m + 1 - i) % MOD;
        ans1 %= MOD;
    }
    cout << ans1 << '\n';
    return 0;
}
