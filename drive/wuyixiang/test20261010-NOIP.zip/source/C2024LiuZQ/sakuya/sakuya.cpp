#include <bits/stdc++.h>
using namespace std;
using ll = long long;
const int MOD = 998244353;
struct p{
    int v, w;
};
vector<p> vc[500005];
int n, m, q, dep[500005], t[500005], p[25], F[500005], w[500005], fl[500005];
bool f[25];
ll sum, cnt;
void dfs1(int x, int fa){
    dep[x] = dep[fa] + 1;
    F[x] = fa;
    for(auto i : vc[x]){
        if(i.v == fa) continue;
        w[i.v] = i.w;
        dfs1(i.v, x);
    }
}
void dfs(int x){
    if(x > m){
        ll s = 0;
        for(int i = 2; i <= m; i++){
            int x = p[i - 1], y = p[i];
            if(dep[x] < dep[y]) swap(x, y);
            while(dep[x] > dep[y]){
                s = (s + w[x]) % MOD;
                x = F[x];
            }
            while(x != y){
                s = (s + w[x] + w[y]) % MOD;
                x = F[x];
                y = F[y];
            }
        }
        cnt++;
        sum = (sum + s) % MOD;
        return;
    }
    for(int i = 1; i <= m; i++){
        if(f[i]) continue;
        f[i] = 1;
        p[x] = t[i];
        dfs(x + 1);
        f[i] = 0;
    }
}
ll fstp(ll x, int y = MOD - 2){
    ll ans = 1;
    while(y){
        if(y & 1) ans = ans * x % MOD;
        x = x * x % MOD;
        y >>= 1;
    }
    return ans;
}
int main(){
    freopen("sakuya.in", "r", stdin);
    freopen("sakuya.out", "w", stdout);
    ios::sync_with_stdio(0);
    cin.tie(0);
    cin >> n >> m;
    for(int i = 1; i <= n - 1; i++){
        int u, v, w;
        cin >> u >> v >> w;
        vc[u].push_back({v, w});
        vc[v].push_back({u, w});
    }
    for(int i = 1; i <= m; i++) cin >> t[i];
    cin >> q;
    dfs1(1, 0);
    while(q--){
        int x, k;
        sum = cnt = 0;
        cin >> x >> k;
        w[x] += k;
        for(auto i : vc[x]){
            if(i.v == F[x]) continue;
            w[i.v] += k;
        }
        dfs(1);
        cout << sum * fstp(cnt) % MOD << '\n';
    }
    return 0;
}
