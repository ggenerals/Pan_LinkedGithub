#include <iostream>
#include <vector>
#define int long long
using namespace std;
const int mod = 998244353;
int n,m,q,U[500005],V[500005],W[500005],a[500005],siz[500005],dep[500005];
int val[500005],fac[500005],inv[500005],ans,gong[500005];
int vis[500005];
vector<int>ve[500005],ve2[500005];
void dfs(int x,int fa)
{
    siz[x] = a[x];
    dep[x] = dep[fa] + 1;
    for(int i = 0;i < ve[x].size();i ++)
    {
        if(ve[x][i] == fa)continue ;
        dfs(ve[x][i],x);
        siz[x] += siz[ve[x][i]];
    }
}
int fpow(int x,int y)
{
    int z = 1;
    while(y)
    {
        if(y & 1)z = z * x % mod;
        x = x * x % mod;
        y >>= 1;
    }
    return z;
}
void init()
{
    fac[0] = fac[1] = 1;
    for(int i = 2;i <= n;i ++)fac[i] = fac[i - 1] * i % mod;
    inv[n] = fpow(fac[n],mod - 2);
    for(int i = n - 1;i >= 0;i --)inv[i] = inv[i + 1] * (i + 1) % mod;
}
int C(int x,int y)
{
    if(x < y)return 0;
    return fac[x] * inv[y] % mod * inv[x - y] % mod;
}
signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    freopen("sakuya.in","r",stdin);
    freopen("sakuya.out","w",stdout);
    cin >> n >> m;
    init();
    for(int i = 1,u,v,w;i < n;i ++)
    {
        cin >> u >> v >> w;
        U[i] = u,V[i] = v,W[i] = w;
        ve[u].push_back(v),ve[v].push_back(u);
        ve2[u].push_back(i),ve2[v].push_back(i);
    }
    for(int i = 1,x;i <= m;i ++)cin >> x,a[x] = 1;
    dfs(1,0);
    cin >> q;
    for(int i = 1;i < n;i ++)
    {
        if(dep[U[i]] < dep[V[i]])swap(U[i],V[i]);
        int L = siz[U[i]],R = m - siz[U[i]];
        //if(i % 100 == 0)
       // cout << i << " " << L << " " << R <<  " 1111111111" << '\n';
        if(!L || !R)continue ;
        if(L < R)swap(L,R);
        if(vis[L])
        {
            val[i] = vis[L],ans += val[i] * W[i] % mod;
            continue ;
        }
        int totans = 0,tot = 0;
        for(int j = 1;j <= (L > R ? R * 2 : R * 2 - 1);j ++)//枚举段数
        {
            if(j % 2)
            {
                int cha = j / 2 + 1,ke = C(L - 1,cha - 1);
                tot = (tot + C(R - 1,cha - 1) * ke * 2) % mod;
                totans = (totans + C(R - 1,cha - 1) * ke % mod * j * 2) % mod;
            }
            else
            {
                int cha = j / 2,ke = C(L - 1,cha);
                tot = (tot + C(R - 1,cha - 1) * ke) % mod;
                totans = (totans + C(R - 1,cha - 1) * ke % mod * j) % mod;
                cha = j / 2 + 1,ke = C(L - 1,cha - 2);
                tot = (tot + C(R - 1,cha - 1) * ke) % mod;
                totans = (totans + C(R - 1,cha - 1) * ke % mod * j) % mod;
            }
        }
        totans = totans * fpow(tot,mod - 2) % mod;
        val[i] = totans,ans += val[i] * W[i] % mod;
        vis[L] = val[i];
        ans %= mod;
    }
    //ans %= mod;
    for(int i = 1;i <= n;i ++)
    {
        for(int j = 0;j < ve[i].size();j ++)gong[i] += val[ve2[i][j]];
        gong[i] %= mod;
    }
    while(q --)
    {
        int x,y;
        cin >> x >> y;
        ans += gong[x] * y % mod;
        ans %= mod;
        cout << ans << '\n';
    }
}
