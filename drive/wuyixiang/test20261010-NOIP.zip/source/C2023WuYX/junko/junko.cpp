#include <iostream>
#include <vector>
using namespace std;
int n,m,opt[200005],val[200005],k[200005];
vector<int>s[200005],t[200005];
int main()
{
    freopen("junko.in","r",stdin);
    freopen("junko.out","w",stdout);
    cin >> n >> m;
    for(int i = 1;i <= m;i ++)
    {
        cin >> opt[i] >> val[i] >> k[i];
        for(int j = 1,x;j <= k[i];j ++)cin >> x,s[i].push_back(x);
        for(int j = 1,x;j <= k[i];j ++)cin >> x,t[i].push_back(x);
    }
    cout << n << " " << 0;
}
