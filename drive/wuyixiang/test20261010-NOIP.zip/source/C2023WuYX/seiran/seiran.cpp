#include <iostream>
#define int long long
using namespace std;
const int mod = 998244353,N = 1e7 + 5;
int n,m,qian[N],dp[N],ans;
int fpow(int x,int y)
{
    int z = 1;
    while(y)
    {
        if(y & 1)z = z * x % mod;
        x = x * x % mod;
        y >>= 1;
    }
    return z;
}
signed main()
{
    freopen("seiran.in","r",stdin);
    freopen("seiran.out","w",stdout);
    cin >> n >> m;
    int tot = fpow(2,n);
    dp[0] = 1,qian[0] = 1;
    for(int i = 1;i <= n;i ++)
    {
        if(i < m)dp[i] = (dp[i - 1] * 2) % mod;
        else dp[i] = ((qian[i - 1] - qian[(i - m - 1 < 0 ? n + 1 : i - m - 1)]) % mod + mod) % mod;
        qian[i] = (qian[i - 1] + dp[i]) % mod;
    }
    cout << ((tot - dp[n]) % mod + mod) % mod << '\n';
    for(int i = 1;i + m - 1 <= n;i ++)
    {
        int ks = dp[max(i - 2,0LL)] % mod,kt = dp[max(n - (i + m),0LL)] % mod;
       // if(i <= 100)cout << i << " " << i + m - 1 << " " << max(i - 2,0LL) << " " << max(n - (i + m),0LL) << '\n';
        ans += ks * kt;
        //if(i <= 100)cout << ans << '\n';
        ans %= mod;
    }
    cout << ans;
}
