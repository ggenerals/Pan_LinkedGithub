#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N=5e5+10,mod=998244353;
int read(){
	char c=getchar();
	int x=0;
	for(;c<'0'||c>'9';c=getchar());
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<3)+(x<<1)+(c^48);
	return x;
}
struct Edge{
	int to,w;
}edge[N];
vector<int> e[N];
int tot=-1;
void add(int u,int v,int w){
	edge[++tot]={v,w};
	e[u].push_back(tot);
	edge[++tot]={u,w};
	e[v].push_back(tot);
	return ;
}
int qpow(int x,int y){
	int res=1;
	while(y){
		if(y&1) res=res*x%mod;
		x=x*x%mod,y>>=1; 
	}
	return res;
}
int a[N],dis[N],dep[N],fa[N][20];
void dfs(int x,int fa){
	for(auto i:e[x]){
		if(edge[i].to==fa) continue;
		dis[edge[i].to]=dis[x]+edge[i].w,dfs(edge[i].to,x);
	}
	return ;
}
signed main(){
	freopen("sakuya.in","r",stdin);
	freopen("sakuya.out","w",stdout);
	int n=read(),m=read();
	for(int i=1;i<n;i++){
		int u=read(),v=read(),w=read();
		add(u,v,w);
	}
	for(int i=1;i<=m;i++) a[i]=read();
	int q=read();
	while(q--){
		int x=read(),w=read(),ans=0;
		for(auto i:e[x]){
			edge[i].w+=w;
			edge[i^1].w+=w;
			if(edge[i].w>=mod) edge[i].w-=mod,edge[i^1].w-=mod;
		}
		for(int i=1;i<=m;i++){
			dis[a[i]]=0,dfs(a[i],0);
			for(int j=1;j<=m;j++){
				ans+=dis[a[j]];
				if(ans>=mod) ans-=mod;
			}
		}
		cout <<ans*qpow(m,mod-2)%mod<<"\n";
	}
	return 0;
}
