#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e7+10,mod=998244353;
int f[N],g[N];
int read(){
	char c=getchar();
	int x=0;
	for(;c<'0'||c>'9';c=getchar());
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<3)+(x<<1)+(c^48);
	return x;
}
signed main(){
	freopen("seiran.in","r",stdin);
	freopen("seiran.out","w",stdout);
	int n=read(),m=read(),sum=0,pw=1,pw2=1;
	for(int i=0;i<m;i++){
		g[i]=pw2;
		pw2<<=1;
		if(pw2>=mod) pw2-=mod;
	}
	f[m]=1,g[m]=pw2-f[m],pw2<<=1;
	if(g[m]<0) g[m]+=mod;
	if(pw2>=mod) pw2-=mod;
	for(int i=m+1;i<=n;++i){
		f[i]=pw*(i-m+2)%mod-sum;
		if(f[i]<0) f[i]+=mod;
		g[i]=pw2-f[i],sum=(sum<<1)+f[i-m],pw<<=1,pw2<<=1;
		if(g[i]<0) g[i]+=mod;
		if(pw>=mod) pw-=mod;
		if(pw2>=mod) pw2-=mod;
		if(sum>=mod) sum-=mod;
		if(sum>=mod) sum-=mod;
	}
	cout <<f[n]<<"\n";
	int ans=0;
	for(int i=1;i<=n-m+1;i++){
		if(i==1) ans+=g[n-m-i];
		else if(i==n-m+1) ans+=g[i-2];
		else ans+=g[i-2]*g[n-m-i]%mod;
		if(ans>=mod) ans-=mod;
	}
	cout <<ans;
	return 0;
}
