#include <bits/stdc++.h>
#define ls (x<<1)
#define rs (x<<1|1)
using namespace std;
const int N=2e5+10;
int l[N],r[N];
int read(){
	char c=getchar();
	int x=0;
	for(;c<'0'||c>'9';c=getchar());
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<3)+(x<<1)+(c^48);
	return x;
}
priority_queue<int> q[N];
int tr[N<<2];
void up(int x){
	tr[x]=max(tr[ls],tr[rs]);
	return ;
}
void upd(int x,int l,int r,int pos,int k){
	if(l==r){
		tr[x]=k;
		return ;
	}
	int mid=(l+r)>>1;
	if(pos<=mid) upd(ls,l,mid,pos,k);
	else upd(rs,mid+1,r,pos,k);
	up(x);
	return ;
}
int qry(int x,int l,int r,int L,int R){
	if(L<=l&&r<=R) return tr[x];
	int mid=(l+r)>>1,res=0;
	if(L<=mid) res=max(res,qry(ls,l,mid,L,R));
	if(R>mid) res=max(res,qry(rs,mid+1,r,L,R));
	return res;
}
int main(){
	freopen("cheat.in","r",stdin);
	freopen("cheat.out","w",stdout);
	int n=read(),m=read();
	for(int i=1;i<=m;i++){
		l[i]=read(),r[i]=read();
		q[l[i]].push(r[i]);
	}
	for(int i=1;i<=n;i++){
		if(!q[i].empty()) upd(1,1,n,i,q[i].top());
	}
	int t=read();
	while(t--){
		int ans=0,idx=read(),now=read(),t=read();
		bool flag=0;
		if(q[l[idx]].top()==r[idx]){
			flag=1;
			q[l[idx]].pop();
			if(!q[l[idx]].empty()) upd(1,1,n,l[idx],q[l[idx]].top());
			else upd(1,1,n,l[idx],0);
		}
		while(now<t){
			int x=qry(1,1,n,1,now);
			if(x<=now){
				ans=-1;
				break;
			}
			now=x,ans++;
		}
		cout <<ans<<"\n";
		if(flag){
			q[l[idx]].push(r[idx]);
			upd(1,1,n,l[idx],r[idx]);
		}
	}
	return 0;
}
