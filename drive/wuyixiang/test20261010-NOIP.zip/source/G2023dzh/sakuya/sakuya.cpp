#include<bits/stdc++.h>
// #define int long long
using namespace std;
const int mod=998244353;
struct egde{
	int to,vl,next;
}a[1000010];
int head[500010],ed,n,m,as[500010],dp[500010],sz[500010];
vector<int>v[500010],t[500010];
bool vis[500010];
void add(int x,int y,int z)
{
	ed++;
	a[ed].to=y;
	a[ed].vl=z;
	a[ed].next=head[x];
	head[x]=ed;
}
void dfs1(int x,int fa)
{
	sz[x]=vis[x];
	for(int i=head[x];i!=0;i=a[i].next)
	{
		if(a[i].to==fa)
			continue;
		dfs1(a[i].to,x);
		sz[x]+=sz[a[i].to];
		dp[x]+=dp[a[i].to];
		if(dp[x]>=mod)
			dp[x]-=mod;
		dp[x]+=1ll*sz[a[i].to]*a[i].vl%mod;
		if(dp[x]>=mod)
			dp[x]-=mod;
	}
}
void dfs2(int x,int fa,int vl)
{
	if(x!=fa){
		dp[x]=dp[fa]-1ll*sz[x]*vl%mod;
		if(dp[x]<0)
			dp[x]+=mod;
		dp[x]+=1ll*(m-sz[x])*vl%mod;
		if(dp[x]>=mod)
			dp[x]-=mod;
	}
	if(vis[x]==1){
		as[0]+=dp[x];
		if(as[0]>=mod)
			as[0]-=mod;
	}
	for(int i=head[x];i!=0;i=a[i].next)
		if(a[i].to!=fa)
			dfs2(a[i].to,x,a[i].vl);
}
int fp(int x,int y)
{
	int as=1;
	while(y){
		if(y&1)
			as=1ll*as*x%mod;
		x=1ll*x*x%mod;
		y=y>>1;
	}
	return as;
}
// void dfs(int x)
// {
// 	if(x==n+1){
// 		for(int i=1;i<n;i++){
// 			s[p[i]][p[i+1]]++;
// 		}
// 		return;
// 	}
// 	for(int i=1;i<=n;i++)
// 	{
// 		if(use[i]==0){
// 			use[i]=1;
// 			p[x]=i;
// 			dfs(x+1);
// 			use[i]=0;
// 		}
// 	}
// }
void dfs3(int x,int fa)
{
	int sum=0;
	for(int i=head[x];i!=0;i=a[i].next){
		if(a[i].to!=fa){
			sum+=1ll*sz[a[i].to]*(m-sz[a[i].to])%mod*2%mod;
			if(sum>=mod)
				sum-=mod;
			dfs3(a[i].to,x);
		}
	}
	sum+=1ll*sz[x]*(m-sz[x])%mod*2%mod;
	// cout<<x<<' '<<sum<<'\n';
	for(int i=0;i<v[x].size();i++)
		as[t[x][i]]=1ll*sum*v[x][i]%mod;
}
signed main()
{
	freopen("sakuya.in","r",stdin);
	freopen("sakuya.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	// for(int i=1;i<=10;i++){
	// 	memset(s,0,sizeof(s));
	// 	n=i;
	// 	dfs(1);
	// 	for(int j=1;j<=i;j++){
	// 		for(int k=1;k<=i;k++){
	// 			cout<<s[i][j]<<' ';
	// 		}
	// 		cout<<'\n';
	// 	}
	// 	cout<<'\n';
	// }
	int q,inv=1,fac=1;
	cin>>n>>m;
	for(int i=1;i<n;i++){
		int x,y,z;
		cin>>x>>y>>z;
		add(x,y,z);
		add(y,x,z);
	}
	for(int i=1;i<=m;i++){
		int x;
		cin>>x;
		vis[x]=1;
		inv=1ll*inv*i%mod;
		fac=1ll*fac*i%mod;
	}
	inv=fp(inv,mod-2);
	fac=1ll*fac*fp(m,mod-2)%mod;
	// cout<<inv<<'\n';
	dfs1(1,1);
	dfs2(1,1,0);
	cin>>q;
	for(int i=1;i<=q;i++){
		int x,y;
		cin>>x>>y;
		v[x].push_back(y);
		t[x].push_back(i);
	}
	dfs3(1,1);
	// cout<<as[0]<<'\n';
	for(int i=1;i<=q;i++){
		// cout<<as[i]<<'\n';
		as[i]+=as[i-1];
		if(as[i]>=mod)
			as[i]-=mod;
	}
	// cout<<'\n';
	for(int i=1;i<=q;i++){
		as[i]=1ll*as[i]*fac%mod*inv%mod;
		cout<<as[i]<<'\n';
	}
	return 0;
}