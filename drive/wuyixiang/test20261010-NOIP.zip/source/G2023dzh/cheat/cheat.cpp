#include<bits/stdc++.h>
using namespace std;
int mx[200010][20],cx[200010][20],mi[200010],ci[200010],l[200010],r[200010];
vector<int>id[200010];
signed main()
{
	freopen("cheat.in","r",stdin);
	freopen("cheat.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int n,m,maxx=0,caxx=0,q;
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int x,y;
		cin>>x>>y;
		l[i]=x;
		r[i]=y;
		id[x].push_back(i);
	}
	for(int i=1;i<=n;i++){
		for(int j=0;j<id[i].size();j++){
			// cout<<r[id[i][j]]<<' '<<r[maxx]<<'\n';
			if(r[id[i][j]]>r[maxx]){
				caxx=maxx;
				maxx=id[i][j];
				// cout<<maxx<<' '<<caxx<<' '<<j<<'\n';
			}
			else if(r[id[i][j]]>r[caxx]){
				caxx=id[i][j];
				// cout<<maxx<<' '<<caxx<<' '<<j<<'\n';
			}
		}
		if(r[maxx]<=i)
			maxx=0;
		if(r[caxx]<=i)
			caxx=0;
		mi[i]=maxx;
		ci[i]=caxx;
		mx[i][0]=r[maxx];
		// cout<<mx[i][0]<<'\n';
		cx[i][0]=r[caxx];
		// cout<<cx[i][0]<<'\n';
		if(cx[i][0]==0)
			cx[i][0]=i;
		if(mx[i][0]==0){
			// cout<<mx[i][0]
			mx[i][0]=i;
		}
		// cout<<maxx<<' '<<caxx<<' '<<mx[i][0]<<' '<<cx[i][0]<<"\n\n";
	}
	for(int i=1;i<=log2(n);i++)
		for(int j=1;j<=n;j++)
			mx[j][i]=mx[mx[j][i-1]][i-1],cx[j][i]=cx[cx[j][i-1]][i-1];
	cin>>q;
	while(q--)
	{
		int id,st,ed,as=0;
		cin>>id>>st>>ed;
		if(ed<=st){
			cout<<"0\n";
			continue;
		}
		for(int i=log2(n);i>=0;i--)
			if(mx[st][i]<l[id]&&mx[st][i]<ed)
				st=mx[st][i],as+=(1<<i);
		if(st<l[id]){
			as++;
			st=mx[st][0];
		}
		// cout<<st<<' '<<mi[st]<<'\n';
		if(st>=ed){
			cout<<as<<'\n';
			continue;
		}
		if(mi[st]==id){
			for(int i=log2(n);i>=0;i--)
				if(mi[cx[st][i]]==id&&cx[st][i]<ed)
					st=cx[st][i],as+=(1<<i);
			st=cx[st][0];
			as++;			
		}
		// cout<<st<<'\n';
		if(st>=ed){
			cout<<as<<'\n';
			continue;
		}
		if(mi[st]==id){
			cout<<"-1\n";
			continue;
		}
		for(int i=log2(n);i>=0;i--)
			if(mx[st][i]<ed)
				st=mx[st][i],as+=(1<<i);
		if(st<ed){
			st=mx[st][0];
			as++;			
		}
		if(st<ed)
			cout<<"-1\n";
		else
			cout<<as<<'\n';
	}
	return 0;
}