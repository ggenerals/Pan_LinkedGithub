#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
int fac[20000010],inv[20000010],n,m,as1,as2,dp[2][2010];
bool vis[20];
int fp(int x,int y)
{
	int as=1;
	x=(x%mod+mod)%mod;
	while(y)
	{
		if(y&1)
			as=1ll*as*x%mod;
		x=1ll*x*x%mod;
		y=y>>1;
	}
	return as;
}
int c(int x,int y){
	if(y>x)
		return 0;
	return 1ll*fac[x]*inv[y]%mod*inv[x-y]%mod;
}
void dfs(int x)
{
	if(x==n+1){
		int sum=0,len=0;
		for(int i=1;i<=n;i++){
			if(vis[i]==1)
				len++;
			else
				len=0;
			if(len>=m)
				sum++;
		}
		if(sum==0)
			return;
		as1++;
		if(sum==1)
			as2++;
		// cout<<sum<<'\n';
		for(int i=1;i<=n;i++)
			cout<<vis[i]<<' ';
		cout<<'\n';
		// cout<<"\n\n";
		return;
	}
	vis[x]=1;
	dfs(x+1);
	vis[x]=0;
	dfs(x+1);
}
signed main()
{
	freopen("seiran.in","r",stdin);
	freopen("seiran.out","w",stdout);
	int as=0,s1=0,s2=0;
	cin>>n>>m;
	if(m==1){
		int p=fp(2,n)-1;
		if(p<0)
			p+=mod;
		cout<<p<<'\n'<<n<<'\n';
		return 0;
	}
	if(n<=20){
		dfs(1);
		cout<<as1<<'\n'<<as2;
		return 0;
	}
	// fac[0]=1;
	// for(int i=1;i<=2*n;i++)
	// 	fac[i]=1ll*fac[i-1]*i%mod;
	// inv[2*n]=fp(fac[2*n],mod-2);
	// for(int i=2*n-1;i>=0;i--)
	// 	inv[i]=1ll*inv[i+1]*(i+1)%mod;
	dp[0][0]=1;
	for(int i=1;i<=n;i++){
		dp[i&1][0]=dp[(i-1)&1][0];
		for(int j=1;j<=min(i,m-1);j++){
			dp[i&1][j]=dp[(i-1)&1][j-1];
			dp[i&1][0]+=dp[(i-1)&1][j];
			if(dp[i&1][0]>=mod)
				dp[i&1][0]-=mod;
		}
		if(i==n-m-2){
			for(int j=0;j<m;j++){
				s1+=dp[i&1][j];
				if(s1>=mod)
					s1-=mod;
			}
		}
		if(i==n-m-1){
			for(int j=0;j<m;j++){
				s2+=dp[i&1][j];
				if(s2>=mod)
					s2-=mod;
			}
		}
	}
	// cout<<dp[2][1][1]<<'\n';
	// for(int i=1;i<=n;i++){
	// 	for(int j=0;j<=m;j++)
	// 		cout<<dp[i][j]<<"  ";
	// 	cout<<'\n';
	// }
	as=fp(2,n);
	for(int i=0;i<m;i++){
		as-=dp[n&1][i];
		if(as<0)
			as+=mod;
	}
	cout<<as<<'\n';
	// cout<<s1<<' '<<s2<<'\n';
	as=s2*2%mod+1ll*s1*(n-m-1)%mod;
	if(as>=mod)
		as-=mod;
	cout<<as;
	return 0;
}