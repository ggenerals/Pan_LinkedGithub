#include <bits/stdc++.h>

using namespace std;
using ll = long long;

const int MAXN = 5e5 + 5, Mod = 998244353;

vector<pair<int, int>> g[MAXN];
int n, m, sz[MAXN];
ll ans, f[MAXN];

ll qpow(ll x, int k = Mod - 2) {
  ll ret = 1;
  for (; k; k >>= 1, (x *= x) %= Mod) {
    if (k & 1) (ret *= x) %= Mod;
  }
  return ret;
}

void dfs(int x, int fx) {
  for (auto [y, w] : g[x]) {
    if (y != fx) {
      dfs(y, x), sz[x] += sz[y];
      ll s = 1ll * sz[y] * (m - sz[y]) % Mod;
      (f[x] += s) %= Mod, (f[y] += s) %= Mod, (ans += s * w) %= Mod;
    }
  }
}

int main() {
  freopen("sakuya.in", "r", stdin);
  freopen("sakuya.out", "w", stdout);
  ios::sync_with_stdio(0), cin.tie(0);
  cin >> n >> m;
  for (int i = 1, u, v, w; i < n; i++) {
    cin >> u >> v >> w;
    g[u].push_back({v, w});
    g[v].push_back({u, w});
  }
  for (int i = 1, x; i <= m; i++) {
    cin >> x, sz[x] = 1;
  }
  dfs(1, 0);
  ll kkk = qpow(m) * 2 % Mod;
  int T; cin >> T;
  for (int x, k; T--; ) {
    cin >> x >> k;
    (ans += f[x] * k) %= Mod;
    cout << ans * kkk % Mod << '\n';
  }
  return 0;
}