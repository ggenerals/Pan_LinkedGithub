#include <bits/stdc++.h>

using namespace std;
using ll = long long;

const int MAXN = 1e7 + 5, Mod = 998244353;

int n, m;
ll ans, sum = 1, dp[MAXN] = {1}, pwr[MAXN] = {1};

int main() {
  freopen("seiran.in", "r", stdin);
  freopen("seiran.out", "w", stdout);
  ios::sync_with_stdio(0), cin.tie(0);
  cin >> n >> m;
  for (int i = 1; i <= n; i++) {
    pwr[i] = pwr[i - 1] * 2 % Mod;
    if (i >= m + 1) (sum += Mod - dp[i - m - 1]) %= Mod;
    dp[i] = sum + (i < m);
    (sum += dp[i]) %= Mod;
  }
  for (int i = 1; i + m - 1 <= n; i++) {
    (ans += dp[max(0, i - 2)] * dp[max(0, n - (i + m))]) %= Mod;
  }
  cout << (pwr[n] - dp[n] + Mod) % Mod << '\n' << ans;
  return 0;
}