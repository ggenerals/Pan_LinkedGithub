#include <bits/stdc++.h>

using namespace std;

const int MAXN = 2e5 + 5, B = 450, K = 451, INF = 1e7;

int nxt[MAXN], walk[MAXN], premx[MAXN];
int n, m, fir[MAXN], sec[MAXN];
int L[MAXN], R[MAXN], kuaimax[K];

struct Kuai {
  int beg, ed;

  void rebuild() {
    for (int i = beg; i <= ed; i++) {
      premx[i] = max((i == beg ? fir[i] : premx[i - 1]), fir[i]);
    }
    for (int i = ed; i >= beg; i--) {
      if (premx[i] <= i) {
        nxt[i] = -1, walk[i] = INF;
      } else if (premx[i] <= ed) {
        nxt[i] = nxt[premx[i]], walk[i] = walk[premx[i]] + 1;
      } else {
        nxt[i] = premx[i], walk[i] = 1;
      }
    }
  }

  int Walk(int s, int t, int premax) {
    int ans = 0;
    premax = max(premax, premx[s]);
    while (s < t) {
      if (premax == s) return INF;
      int nxt = premax;
      if (nxt >= t) return ans + 1; 
      for (int i = s + 1; i <= min(t, nxt); i++) {
        premax = max(premax, fir[i]);
      }
      s = nxt, ans++;
    }
    return ans;
  }

  int Jumpout(int &s, int premax) {
    premax = max(premax, premx[s]);
    if (premax <= s) return INF;
    s = premax;
    if (s > ed) return 1;
    int ret = 1 + walk[s];
    s = nxt[s];
    return ret;
  }
} kuai[K];

int cntkuai, viskuai[MAXN];

int Walk(int s, int t) {
  int pt = viskuai[t];
  int ret = 0;
  while (viskuai[s] < pt) {
    int cnt = kuai[viskuai[s]].Jumpout(s, kuaimax[viskuai[s] - 1]);
    ret += cnt;
    if (ret > n) return ret;
  }
  if (s >= t) return ret;
  return ret + kuai[pt].Walk(s, t, kuaimax[pt - 1]);
}

void init() {
  for (int i = 1; i <= cntkuai; i++) {
    kuaimax[i] = max(kuaimax[i - 1], premx[kuai[i].ed]);
  }
}

int main() {
  freopen("cheat.in", "r", stdin);
  freopen("cheat.out", "w", stdout);
  ios::sync_with_stdio(0), cin.tie(0);
  cin >> n >> m;
  for (int i = 1; i <= n; i++) fir[i] = i;
  for (int i = 1, l, r; i <= m; i++) {
    cin >> l >> r;
    L[i] = l, R[i] = r;
    if (r > fir[l]) {
      sec[l] = fir[l], fir[l] = r;
    } else sec[l] = max(sec[l], r);
  }
  for (int i = 1; i <= n; i++) {
    if (i % B == 1) {
      kuai[++cntkuai].beg = i;
    }
    viskuai[i] = cntkuai;
    kuai[cntkuai].ed = i;
  }
  for (int i = 1; i <= cntkuai; i++) {
    kuai[i].rebuild();
  }
  int T; cin >> T;
  for (int id, s, t; T--; ) {
    cin >> id >> s >> t;
    int l = L[id], r = R[id];
    int tfir = fir[l];
    fir[l] = (fir[l] == r ? sec[l] : fir[l]);
    kuai[viskuai[l]].rebuild(), init();
    int ans = Walk(s, t);
    cout << (ans <= n ? ans : -1) << '\n';
    fir[l] = tfir, kuai[viskuai[l]].rebuild();
  }
  return 0;
}