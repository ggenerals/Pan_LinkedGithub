#include <bits/stdc++.h>

using namespace std;

const int MAXN = 1e5 + 5, MAXM = 1e5 + 5, INF = INT_MAX;

struct Edge {
  int op, val;
  vector<int> p;
} edge[MAXM];

bool vis[MAXN * 2];
vector<int> g[MAXN * 2];
int n, m, nn, cntnode;

void dfs(int x) {
  if (vis[x]) return ;
  vis[x] = 1, cntnode += (x <= n);
  for (auto y : g[x]) dfs(y);
}

int getans(int lim) {
  nn = n;
  for (int i = 1; i <= m; i++) {
    if (edge[i].val > lim) continue;
    auto &p = edge[i].p;
    if (edge[i].op == 1 || p.size() > 4) {
      nn++;
      for (auto u : p) {
        g[u].push_back(nn);
        g[nn].push_back(u);
      }
    } else if (p.size() == 4) {
      for (int i = 0; i < 4; i++) {
        g[p[i]].push_back(p[3 - i]);
      }
    }
  }
  int ans = 0;
  for (int i = 1; i <= nn; i++) {
    if (!vis[i]) {
      dfs(i), ans = max(ans, cntnode), cntnode = 0;
    }
  }
  for (int i = 1; i <= nn; i++) {
    g[i].clear(), vis[i] = 0;
  }
  return ans;
}

int main() {
  freopen("junko.in", "r", stdin);
  freopen("junko.out", "w", stdout);
  ios::sync_with_stdio(0), cin.tie(0);
  cin >> n >> m;
  for (int op, val, k, i = 1; i <= m; i++) {
    cin >> op >> val >> k, k <<= 1;
    edge[i].op = op, edge[i].val = val;
    for (int u; k--; ) cin >> u, edge[i].p.push_back(u);
  }
  int ans = getans(INF);
  int l = 0, r = INF;
  while (l < r) {
    int mid = (l + r) >> 1;
    getans(mid) == ans ? r = mid : l = mid + 1;
  }
  cout << ans << ' ' << l;
  return 0;
}