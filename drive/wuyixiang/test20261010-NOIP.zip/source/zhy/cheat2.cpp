#include <bits/stdc++.h>
using namespace std;
const int N = 2e5 + 5;
const int inf = 1e9;
int f[20][N],g[20][N],ma[N];
struct node { int l,r; } p[N];
inline int solve(int d , int s , int t) {
    if(s >= t) return 0;
    if(p[d].r <= s || p[d].l >= t) d = 0;
    if(s >= p[d].l && ma[s] != d) d = 0;
    int ls = s,num = 0;
    if(ma[s] == d) {
        if(g[0][s] == 0) return -inf;
        num = 1;
        s = g[0][s];
        for(int i = 18;i >= 0;-- i) {
            if(ma[g[i][s]] == d && g[i][s] <= t) {
                s = g[i][s];
                num += (1 << i);
            }
        }
    }
    else {
        if(f[0][s] == 0) return -inf;
        num = 1;
        s = f[0][s];
        if(ma[s] == d) return 1 + solve(d , s , t);
        if(s <= p[d].l) {
            for(int i = 18;i >= 0;i --) {
                if(f[i][s] <= p[d].l && f[i][s]) {
                    s = f[i][s];
                    num += (1 << i);
                }
            }
        }
        else {
            for(int i = 18;i >= 0;i --) {
                if(f[i][s] <= t && f[i][s]) {
                    s = f[i][s];
                    num += (1 << i);
                }
            }
        }
    }
    if(s == ls) return -inf;
    return num + solve(d , s , t);
}
inline int solve2(int d , int s , int t) {
    if(s == 0) return -inf;
    if(s >= t) return 0;
    if(ma[s] == d) return 1 + solve2(d , g[0][s] , t);
    else return 1 + solve2(d , f[0][s] , t);
}
int main() {
    freopen("cheat.in","r",stdin);
    freopen("cheat2.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n,m,q;
    cin >> n >> m;
    for(int i = 1;i <= m;i ++) {
        f[0][i] = g[0][i] = 0;
    }
    for(int i = 1;i <= m;i ++) {
        int l,r;
        cin >> l >> r;
        p[i] = (node){l , r};
        if(r > f[0][l]) {
            g[0][l] = f[0][l];
            f[0][l] = r;
            ma[l] = i;
        }
        else {
            g[0][l] = max(g[0][l] , r);
        }
    }
    for(int i = 1;i <= n;i ++) {
        if(f[0][i - 1] > f[0][i]) {
            g[0][i] = max(f[0][i] , g[0][i - 1]);
            ma[i] = ma[i - 1];
            f[0][i] = f[0][i - 1];
        }
        else {
            g[0][i] = max(g[0][i] , f[0][i - 1]);
        }
        if(f[0][i] <= i) {
            f[0][i] = 0;
            ma[i] = 0;
        }
        if(g[0][i] <= i) {
            g[0][i] = 0;
        }
    }
    // for(int i = 1;i <= n;i ++) {
    //     cout << f[0][i] << " " << g[0][i] << " " << ma[i] << "\n";
    // }
    for(int i = 1;i <= 18;i ++) {
        for(int j = 1;j <= n;j ++) {
            f[i][j] = f[i - 1][f[i - 1][j]];
            g[i][j] = g[i - 1][g[i - 1][j]];
        }
    }
    cin >> q;
    for(int i = 1;i <= q;i ++) {
        int id,s,t;
        cin >> id >> s >> t;
        // if(i <= 100) cout << max(-1 , solve2(id , s, t)) << " ";
        cout << max(-1 , solve(id , s , t)) << "\n";
    }
    return 0;
}