#include <bits/stdc++.h>
using namespace std;
const int mod = 998244353;
const int N = 1e7 + 5;
int f[N];
inline int qpow(int x , int y) {
    int cnt = 1;
    for(int i = y;i;i >>= 1) {
        if(i & 1) cnt = 1ll * cnt * x % mod;
        x = 1ll * x * x % mod;
    }
    return cnt;
}
int main() {
    freopen("seiran.in","r",stdin);
    freopen("seiran.out","w",stdout);
    int n,m;
    cin >> n >> m;
    f[0] = 1;
    for(int i = 1;i <= n;i ++) {
        if(i < m) f[i] = 1ll * f[i - 1] * 2 % mod;
        else {
            f[i] = (1ll * f[i - 1] * 2 % mod - f[max(0 , i - m - 1)]) % mod;
        }
    }
    int ans1,ans2 = 0;
    ans1 = qpow(2 , n) - f[n];
    cout << (ans1 % mod + mod) % mod << "\n";
    for(int i = 0;i <= n - m;i ++) {
        ans2 = (ans2 + 1ll * f[max(0 , i - 1)] * f[max(0 , n - m - i - 1)] % mod) % mod;
    }
    cout << (ans2 % mod + mod) % mod << "\n";
    return 0;
}