#include <bits/stdc++.h>
using namespace std;
const int N = 5e5 + 5;
const int mod = 998244353;
int sum[N],k[N],si[N],L[N],R[N],D[N],num = 0;
int to[N << 1],nxt[N << 1],h[N],val[N << 1],cnt = 0;
inline void addedge(int u , int v , int w) {
    to[++ cnt] = v;
    nxt[cnt] = h[u];
    h[u] = cnt;
    val[cnt] = w;
}
inline void dfs(int x , int fa) {
    L[x] = num + 1;
    for(int i = h[x];i;i = nxt[i]) {
        if(to[i] == fa) continue;
        D[to[i]] = ++ num;
    }
    R[x] = num;
    for(int i = h[x];i;i = nxt[i]) {
        if(to[i] == fa) continue;
        k[to[i]] = val[i];
        dfs(to[i] , x);
        si[x] += si[to[i]];
    }
}
inline int qpow(int x , int y) {
    int cnt = 1;
    for(int i = y;i;i >>= 1) {
        if(i & 1) cnt = 1ll * cnt * x % mod;
        x = 1ll * x * x % mod;
    }
    return cnt;
}
int main() {
    // freopen("3.in","r",stdin);
    freopen("sakuya.in","r",stdin);
    freopen("sakuya.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n,m,q;
    cin >> n >> m;
    for(int i = 1;i < n;i ++) {
        int u,v,w;
        cin >> u >> v >> w;
        addedge(u , v , w);
        addedge(v , u , w);
    }
    for(int i = 1;i <= m;i ++) {
        int p;
        cin >> p;
        si[p] = 1;
    }
    dfs(1 , 0);
    int cnt1 = 0,cnt2 = 1ll * 2 * qpow(m , mod - 2) % mod;
    for(int i = 1;i <= n;i ++) {
        sum[D[i]] = 1ll * si[i] * (m - si[i]) % mod;
        cnt1 = (cnt1 + 1ll * sum[D[i]] * k[i] % mod) % mod;
    }
    for(int i = 1;i <= n;i ++) {
        sum[i] = (sum[i - 1] + sum[i]) % mod;
    }
    cin >> q;
    for(int i = 1;i <= q;i ++) {
        int x,k;
        cin >> x >> k;
        cnt1 = (cnt1 + 1ll * (sum[D[x]] - sum[D[x] - 1]) * k % mod) % mod;
        cnt1 = (cnt1 + 1ll * (sum[R[x]] - sum[L[x] - 1]) * k % mod) % mod;
        int ans = 1ll * cnt1 * cnt2 % mod;
        cout << (ans % mod + mod) % mod << "\n";
    }
    return 0;
}