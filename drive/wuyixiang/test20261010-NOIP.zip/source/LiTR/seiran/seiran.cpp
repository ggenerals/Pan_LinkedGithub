#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e7+5,mod=998244353;
int f[N],sum[N];
int qpow(int x,int y,int s=1){
	for(x%=mod;y;x*=x,x%=mod,y>>=1)
		if(y&1)s*=x,s%=mod;
	return s;
}
signed main(){
	ios::sync_with_stdio(0);cin.tie(0);
	freopen("seiran.in","r",stdin);
	freopen("seiran.out","w",stdout);
	int n,m;cin>>n>>m;
	if(n==m)return cout<<"1\n1",0;
	f[0]=sum[0]=1,f[1]=2,sum[1]=3;
	for(int i=2;i<m;i++)f[i]=f[i-1]*2%mod,sum[i]=(sum[i-1]+f[i])%mod;
	f[m]=(f[m-1]*2-1+mod)%mod,sum[m]=(sum[m-1]+f[m])%mod;
	for(int i=m+1;i<=n;i++)f[i]=(sum[i-1]-sum[i-m-1])%mod,sum[i]=(sum[i-1]+f[i])%mod;
	cout<<(qpow(2,n)-f[n]+mod)%mod<<"\n";
	int ans=f[n-m-1]*2%mod;
	for(int l=2;l+m-1<n;l++){
		int r=l+m-1;
		ans+=f[l-2]*f[n-r-1]%mod,ans%=mod;
	}
	cout<<ans;
}