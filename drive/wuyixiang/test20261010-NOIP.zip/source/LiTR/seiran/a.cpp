#include<bits/stdc++.h>
using namespace std;
signed main(){
cout<<"Hello world!\n";
}
