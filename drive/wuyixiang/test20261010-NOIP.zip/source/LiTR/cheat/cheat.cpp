#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=2e5+5;
int n,m;
struct node{
	int l,r,id;
}a[N];
int tr[N];
int pos[N];
inline void rd(int &x){
	char c=getchar();x=0;
	while(c>'9'||c<'0')c=getchar();
	while(c>='0'&&c<='9')x=x*10+c-'0',c=getchar();
}
inline void print(int x){
	if(x>9)print(x/10);
	putchar(x%10+'0');
}
inline int lowbit(int x){return x&-x;}
inline void update(int x,int k){
	while(x<=n)tr[x]+=k,x+=lowbit(x);
}
inline int query(int x,int s=0){
	while(x)s+=tr[x],x-=lowbit(x);
}
signed main(){
	ios::sync_with_stdio(0);cin.tie(0);
	freopen("cheat.in","r",stdin);
	freopen("cheat.out","w",stdout);
	rd(n),rd(m);
	for(int i=1;i<=m;i++)rd(a[i].l),rd(a[i].r),a[i].id=i;
	sort(a+1,a+m+1,[](node A,node B){return A.l==B.l?A.r>B.r:A.l<B.l;});
	int q;rd(q);
	for(int i=1;i<=q;i++){
		int id,s,t;rd(id),rd(s),rd(t);
	}
	int tot=0,ans=0;
	for(int i=1;i<=q;i++){
		while(tot<=a[i].r){
			if(a[i].l<a[i-1].r)tot++,ans++;	
		}
	}
	int cnt=0;
	for(int i=1;i<=n;i++)
		if(a[i].r>a[i-1].r)cnt++;
	for(int i=1;i<=n;i++){
	}
}