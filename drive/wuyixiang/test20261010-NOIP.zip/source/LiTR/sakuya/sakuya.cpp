#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353,N=5e5+5;
int n,m,q;
struct node{
	int v,w;
};
vector<node>g[N];
int siz[N],cnt[N];
int qpow(int x,int y,int cnt=1){
	for(x%=mod;y;x*=x,x%=mod,y>>=1)
		if(y&1)cnt*=x,cnt%=mod;
	return cnt;
}
void dfs(int x,int fa){
	for(auto [y,w]:g[x])
		if(y!=fa)
			dfs(y,x),siz[x]+=siz[y];
}
int solve(int x,int fa){
	int sum=0;
	for(auto [y,w]:g[x]){
		if(y==fa){
			cnt[x]+=siz[x]*(m-siz[x]),cnt[x]%=mod;
			continue;
		}
		cnt[x]+=siz[y]*(m-siz[y]),cnt[x]%=mod;
		sum+=solve(y,x)+w*siz[y]%mod*(m-siz[y])%mod,sum%=mod;
	}
	return sum;
}
inline void rd(int &x){
	char c=getchar();x=0;
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9')x=x*10+c-'0',c=getchar();
}
void print(int x){
	if(x>9)print(x/10);
	putchar(x%10+'0');
}
signed main(){
	ios::sync_with_stdio(0);cin.tie(0);
	freopen("sakuya.in","r",stdin);
	freopen("sakuya.out","w",stdout);
	rd(n),rd(m);
	for(int i=1,u,v,w;i<n;i++)
		rd(u),rd(v),rd(w),g[u].push_back({v,w}),g[v].push_back({u,w});
	for(int i=1,x;i<=m;i++)rd(x),siz[x]=1;
	dfs(1,1);
	int ans=solve(1,1);
	rd(q);
	int inv=qpow(m,mod-2)*2%mod;
	while(q--){
		int x,k;rd(x),rd(k);
		ans+=cnt[x]*k%mod,ans%=mod;
		print(ans*inv%mod),puts("");
	}
}