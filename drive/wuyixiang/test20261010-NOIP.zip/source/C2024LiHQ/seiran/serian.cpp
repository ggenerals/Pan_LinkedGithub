#include<bits/stdc++.h>
// #define int long long
using namespace std;
using ll=long long;
const int N=1e7+5,M=998244353;
ll qp(ll a,int b){ll s=1;while(b){if(b&1)s=s*a%M;a=a*a%M,b>>=1;}return s;}
int n,m;
int f[N][2],g[N];
signed main(){
	ios::sync_with_stdio(0),cin.tie(0);
	freopen("serian.in","r",stdin);
	freopen("serian.out","w",stdout);
	cin>>n>>m;
	f[0][0]=1,g[0]=1;
	for(int i=1;i<=n;i++){
		f[i][0]=(f[i-1][0]+f[i-1][1])%M;
		f[i][1]=f[i][0];
		if(i>=m)f[i][1]=(f[i][1]-f[i-m][0]+M)%M;
		g[i]=(f[i][0]+f[i][1])%M;
	}
	cout<<(qp(2,n)-g[n]+M)%M<<'\n';
	ll ans=0;
	for(int i=1;i+m-1<=n;i++){
		ll v=(i>1?g[i-2]:1ll);
		v=v*(i+m<=n?g[n-(i+m)]:1ll)%M;
		ans=(ans+v)%M;
	}
	cout<<ans;
	return 0;
}