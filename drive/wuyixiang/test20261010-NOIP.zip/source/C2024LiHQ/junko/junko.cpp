#include<bits/stdc++.h>
// #define int long long
using namespace std;
const int N=5e5+5,V=2e6+5;
int n,m,opt[N],val[N],k[N];
vector<int>S[N],T[N];
int dfn[V],low[V],cnt;
vector<int>g[V];
int tot;
int ans,mx;
int scc[V],sc;
vector<int>e[V];
int dot[V],F[V];
int deg[V];
stack<int>st;
bitset<V>ins;
inline void SCC(int x){
	dfn[x]=low[x]=++cnt;
	st.push(x),ins[x]=1;
	for(int y:g[x]){
		if(!dfn[y])SCC(y),low[x]=min(low[x],low[y]);
		else if(ins[y])low[x]=min(low[x],dfn[y]);
	}
	if(low[x]>=dfn[x]){
		++sc;
		int k;
		while((k=st.top())!=x){
			st.pop();
			dot[sc]+=(k<=n);
			scc[k]=sc;
			ins[k]=0;
		}
		st.pop();
		dot[sc]+=(x<=n);
		scc[x]=sc;
		ins[x]=0;
	}
}
queue<int>q;
void topo(){
	for(int i=1;i<=sc;i++)if(!deg[i])q.push(i),F[i]=dot[i];
	while(!q.empty()){
		int x=q.front();q.pop();
		mx=max(mx,F[x]);
		for(int y:e[x]){
			F[y]=max(F[y],F[x]+dot[y]);
			if(!--deg[y])q.push(y);
		}
	}
}
bool check(int v){
	mx=0;
	tot=n;
	for(int i=1;i<=m;i++){
		if(val[i]>v)continue;
		if(opt[i]==1){
			int X=++tot;
			for(int j=0;j<k[i];j++)
				g[S[i][j]].push_back(X);
			for(int j=0;j<k[i];j++)
				g[X].push_back(T[i][j]);
		}
		else{
			int lst=-1;
			for(int j=1;j<k[i];j++){
				int X=++tot;
				g[X].push_back(T[i][j-1]);
				g[S[i][j]].push_back(X);
				if(~lst)g[X].push_back(lst);
				lst=X;
			}
			lst=-1;
			for(int j=k[i]-2;~j;j--){
				int X=++tot;
				g[X].push_back(T[i][j+1]);
				g[S[i][j]].push_back(X);
				if(~lst)g[X].push_back(lst);
				lst=X;
			}
		}
	}
	cnt=0,sc=0;
	for(int i=1;i<=tot;i++)if(!dfn[i])SCC(i);
	for(int i=1;i<=tot;i++)
		for(int j:g[i])
			if(scc[i]!=scc[j])
				e[scc[i]].push_back(scc[j]),
				++deg[scc[j]];
	topo();
	for(int i=1;i<=sc;i++)e[i].clear(),F[i]=0,dot[i]=0;
	for(int i=1;i<=tot;i++)g[i].clear(),dfn[i]=0;
	return mx>=ans;
}
signed main(){
	ios::sync_with_stdio(0),cin.tie(0);
	freopen("junko.in","r",stdin);
	freopen("junko.out","w",stdout);
	cin>>n>>m;
	int vmax=0;
	for(int i=1;i<=m;i++){
		cin>>opt[i]>>val[i]>>k[i];
		vmax=max(vmax,val[i]);
		for(int j=1,x;j<=k[i];j++)cin>>x,S[i].push_back(x);
		for(int j=1,x;j<=k[i];j++)cin>>x,T[i].push_back(x);
	}
	check(vmax);ans=mx;
	cout<<ans<<' ';
	int l=0,r=vmax;
	while(l<r){
		int d=(l+r)>>1;
		if(check(d))r=d;
		else l=d+1;
	}
	cout<<l;
	return 0;
}