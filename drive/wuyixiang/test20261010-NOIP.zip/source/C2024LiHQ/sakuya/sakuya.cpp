#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=5e5+5,M=998244353;
int qp(int a,int b){int s=1;while(b){if(b&1)s=s*a%M;a=a*a%M,b>>=1;}return s;}
int n,m,q;
int sz[N];
vector<array<int,2>>g[N];
int s[N];
int ans;
void dfs(int x,int f){
	for(auto _:g[x]){
		int y=_[0],v=_[1];
		if(y==f)continue;
		dfs(y,x);
		sz[x]+=sz[y];
		ans=(ans+v*(m-sz[y])%M*sz[y])%M;
		s[x]=(s[x]+(m-sz[y])*sz[y])%M;
	}
	s[x]=(s[x]+(m-sz[x])*sz[x])%M;
}
signed main(){
	ios::sync_with_stdio(0),cin.tie(0);
	freopen("sakuya.in","r",stdin);
	freopen("sakuya.out","w",stdout);
	cin>>n>>m;
	for(int i=1,x,y,z;i<n;i++)
		cin>>x>>y>>z,
		g[x].push_back({y,z}),
		g[y].push_back({x,z});
	for(int i=1,x;i<=m;i++)cin>>x,sz[x]=1;
	dfs(1,0);
	int mul=2*qp(m,M-2)%M;
	cin>>q;
	while(q--){
		int x,k;cin>>x>>k;
		ans=(ans+s[x]*k)%M;
		cout<<ans*mul%M<<'\n';
	}
	return 0;
}