#include<bits/stdc++.h>
// #define int long long
using namespace std;
const int N=2e5+5;
int n,m,q;
array<int,3>gua[N],use[N];
int pos[N];
int ri[N][20];
int findl(int x){
	if(use[1][0]>x)return-1;
	int l=1,r=m;
	while(l<r){
		int d=(l+r+1)>>1;
		if(use[d][0]<=x)l=d;
		else r=d-1;
	}
	return l;
}
int jump(int x,int v){
	while(v)x=ri[x][__lg(v&-v)],v^=(v&-v);
	return x;
}
int calc(int id,int x){
	int l=0,r=m;
	while(l<r){
		int d=(l+r)>>1,tid=jump(id,d);
		if(use[tid][1]>=x)r=d;
		else l=d+1;
	}
	return l+1;
}
int step(int x,int y){
	int l=0,r=m;
	while(l<r){
		int d=(l+r+1)>>1,p=jump(x,d);
		if(p>=y)r=d-1;
		else l=d;
	}
	return l;
}
signed main(){
	ios::sync_with_stdio(0),cin.tie(0);
	freopen("cheat.in","r",stdin);
	freopen("cheat.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)cin>>gua[i][0]>>gua[i][1],gua[i][2]=i;
	sort(gua+1,gua+m+1,
		[&](array<int,3>a,array<int,3>b){
			return a[0]==b[0]?a[1]>b[1]:a[0]<b[0];
		});
	{
		int cnt=0;
		for(int i=1;i<=m;i++)
			if(gua[i][1]>use[cnt][1])
				use[++cnt]=gua[i],
				pos[gua[i][2]]=cnt;
		m=cnt;
	}
	{
		int pos=m;
		for(int i=m;i;i--){
			while(use[pos][0]>use[i][1])--pos;
			ri[i][0]=pos;
		}
	}
	for(int j=1;j<20;j++)
		for(int i=1;i<=m;i++)
			ri[i][j]=ri[ri[i][j-1]][j-1];
	cin>>q;
	while(q--){
		int id,s,t;cin>>id>>s>>t;
		if(s>=t){
			cout<<"0\n";
			continue;
		}
		id=pos[id];
		int ids=findl(s);
		if(ids==id){
			if(ids==1)ids=-1;
			else --ids;
		}
		if(!~ids){
			cout<<"-1\n";
			continue;
		}
		if(use[ri[ids][19]][1]<t){
			cout<<"-1\n";
			continue;
		}
		if(ids>id||use[id-1][1]>=t){
			cout<<calc(ids,t)<<'\n';
			continue;
		}
		int ans=step(ids,id);
		if(findl(use[jump(ids,ans)][1])>id){
			cout<<calc(ids,t)<<'\n';
			continue;
		}
		ids=id-1;
		ids=findl(use[ids][1]);
		++ans;
		if(ids<=id){
			cout<<"-1\n";
			continue;
		}
		ans+=calc(ids,t);
		cout<<ans+1<<'\n';
	}
	return 0;
}