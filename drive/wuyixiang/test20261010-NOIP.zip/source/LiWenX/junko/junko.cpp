#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,minn=INT_MAX;
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	freopen("junko.in","r",stdin);
	freopen("junko.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int opt,val,k;
		cin>>opt>>val>>k;
		for(int j=1;j<=k;j++){
			int x;
			cin>>x;
		}
		for(int j=1;j<=k;j++){
			int x;
			cin>>x;
		}
		minn=min(minn,val);
	}
	cout<<n<<" "<<minn;
	return 0;
}
