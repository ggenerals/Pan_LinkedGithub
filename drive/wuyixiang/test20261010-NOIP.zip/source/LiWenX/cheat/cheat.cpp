#include<bits/stdc++.h>
using namespace std;
const int B=448;
int n,m;
struct node{
	int x,y;
}e[400005];
vector<pair<int,int> > v[400005];
int dis[400005];
bool vis[400005];
inline int bfs(int s,int t,int fl){
	memset(vis,0,sizeof(vis));
	memset(dis,0x3f,sizeof(dis));
	dis[s]=0;
	deque<int> q;
	q.push_front(s);
	while(!q.empty()){
		int x=q.front();
		q.pop_front();
		vis[x]=1;
		if(x==t){
			break;
		}
		for(int i=0;i<(int)v[x].size();i++){
			int dir=v[x][i].first,w=v[x][i].second;
			if(dir==fl){
				continue;
			}
			int y=e[dir].y;
			if(dis[y]>dis[x]+w){
				dis[y]=dis[x]+w;
				if(!vis[y]){
					if(!w){
						q.push_front(y);
					}else{
						q.push_back(y);
					}
				}
			}
		}
	}
	if(dis[t]==0x3f3f3f3f){
		return -1;
	}
	return dis[t];
}
signed main(){
	freopen("cheat.in","r",stdin);
	freopen("cheat.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		cin>>e[i].x>>e[i].y;
		v[e[i].x].push_back({i,1});
	}
	for(int i=2;i<=n;i++){
		e[m+i]={i,i-1};
		v[i].push_back({m+i,0});
	}
	int q;
	cin>>q;
	while(q--){
		int id,s,t;
		cin>>id>>s>>t;
		cout<<bfs(s,t,id)<<"\n";
	}
	return 0;
}
