#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,sum[500005],siz[500005];
bool vis[500005];
vector<pair<int,int> > v[500005];
int ans=0;
const int mod=998244353;
inline void dfs(int x,int fa){
	siz[x]=vis[x];
	for(int i=0;i<(int)v[x].size();i++){
		int y=v[x][i].first,w=v[x][i].second;
		if(y!=fa){
			dfs(y,x);
			siz[x]+=siz[y];
			int cnt=siz[y]*(m-siz[y])%mod*2ll%mod;
			ans=(ans+cnt*w%mod)%mod;
			sum[x]=(sum[x]+cnt)%mod;
			sum[y]=(sum[y]+cnt)%mod;
		}
	}
}
inline int qp(int a,int b){
	int ans=1;
	while(b){
		if(b&1){
			ans=ans*a%mod;
		}
		a=a*a%mod;
		b>>=1;
	}
	return ans;
}
signed main(){
	freopen("sakuya.in","r",stdin);
	freopen("sakuya.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	cin>>n>>m;
	for(int i=1;i<n;i++){
		int x,y,z;
		cin>>x>>y>>z;
		v[x].push_back({y,z});
		v[y].push_back({x,z});
	}
	for(int i=1;i<=m;i++){
		int x;
		cin>>x;
		vis[x]=1;
	}
	dfs(1,0);
	int inv=qp(m*(m-1)%mod,mod-2)*(m-1)%mod;
	int T;
	cin>>T;
	while(T--){
		int x,p;
		cin>>x>>p;
		ans=(ans+sum[x]*p%mod)%mod;
		cout<<ans*inv%mod<<"\n";
	}
	return 0;
}
