#include<bits/stdc++.h>
using namespace std;

const int N=5e5+5,mod=998244353;

struct node{
	int to,next,w;
}e[N<<1];
int h[N],cnt;

int n,m,q;
bool a[N];
int s[N],p[N],sum[N];
int fac[N],invFac[N];
int ans;

int qpow(int a,int b){
	int res=1,x=a;
	while(b){
		if(b&1)res=1ll*x*res%mod;
		x=1ll*x*x%mod;
		b>>=1;
	}
	return res;
}

void Link(int u,int v,int w){
	e[++cnt]={v,h[u],w};
	h[u]=cnt;
}

int C(int n,int m){
	if(n<0||m<0||m>n)return 0;
	return 1ll*fac[n]*invFac[m]%mod*invFac[n-m]%mod;
}

void dfs(int x,int fa){
	s[x]=a[x];
	for(int i=h[x];i;i=e[i].next){
		int y=e[i].to;
		if(y==fa)continue;
		dfs(y,x);
		s[x]+=s[y];
		p[y]=1ll*C(m-1,m-s[y])*2%mod*fac[s[y]]%mod*fac[m-s[y]]%mod*(m-s[y])%mod;
		(sum[y]+=p[y])%=mod;
		(sum[x]+=p[y])%=mod;
		(ans+=1ll*p[y]*e[i].w%mod)%=mod;
	}
}

int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	freopen("sakuya.in","r",stdin);
	freopen("sakuya.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n-1;i++){
		int u,v,w;
		cin>>u>>v>>w;
		Link(u,v,w);
		Link(v,u,w);
	}
	for(int i=1;i<=m;i++){
		int x;
		cin>>x;
		a[x]=true;
	}
	fac[0]=invFac[0]=1;
	for(int i=1;i<=m;i++){
		fac[i]=1ll*fac[i-1]*i%mod;
		invFac[i]=qpow(fac[i],mod-2);
	}
	dfs(1,0);
	cin>>q;
	while(q--){
		int x,v;
		cin>>x>>v;
		(ans+=1ll*sum[x]*v%mod)%=mod;
		cout<<1ll*ans*invFac[m]%mod<<'\n';
	}
	return 0;
}