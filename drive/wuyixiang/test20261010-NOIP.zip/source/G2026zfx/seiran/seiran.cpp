#include<bits/stdc++.h>
using namespace std;

const int N=1e7+5,mod=998244353;

int n,m;
int ans1,ans2;
bool a[N];

void dfs(int x){
	if(x==n+1){
		int l=0,ti=0,ti2=0;
		for(int i=1;i<=n+1;i++){
			if(a[i]){
				l++;
			}else{
				if(l>=m){
					ti++;
					if(l>m)ti2=-mod;
				}
				if(l==m)ti2++;
				l=0;
			}
		}
		ans1+=(ti>0);
		ans2+=(ti2==1);
		return;
	}
	a[x]=true;
	dfs(x+1);
	a[x]=false;
	dfs(x+1);
}

int qpow(int a,int b){
	int res=1,x=a;
	while(b){
		if(b&1)res=1ll*x*res%mod;
		x=1ll*x*x%mod;
		b>>=1;
	}
	return res;
}

int main(){
	freopen("seiran.in","r",stdin);
	freopen("seiran.out","w",stdout);
	cin>>n>>m;
	if(m==1){
		cout<<qpow(2,m)-1<<'\n'<<n;
		return 0;
	}
	dfs(1);
	cout<<ans1<<'\n'<<ans2;
	return 0;
}