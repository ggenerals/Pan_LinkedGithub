#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,pw[10000001],dp[10000001];
const int mod=998244353;
int qp(int a,int b){
	int ans=1;
	while(b){
		if(b&1){
			ans=ans*a%mod;
		}
		a=a*a%mod;
		b>>=1;
	}
	return ans;
}
signed main(){
	freopen("seiran.in","r",stdin);
	freopen("seiran.out","w",stdout);
	cin>>n>>m;
	pw[0]=1;
	dp[0]=1;
	for(int i=1;i<=n;i++){
		pw[i]=pw[i-1]*2%mod;
		if(i<m) dp[i]=pw[i];
		else dp[i]=(dp[i-1]*2%mod-dp[max(0ll,i-m-1)]+mod)%mod;
	}
	cout<<(pw[n]-dp[n]+mod)%mod<<"\n";
	int ans=0;
	for(int i=0;i<=n-m;i++){
		(ans+=dp[max(0ll,i-1)]*dp[max(0ll,n-m-i-1)]%mod)%=mod;
	}
	cout<<ans;
	return 0;
}
