#include <bits/stdc++.h>
#define int long long

using namespace std;

const int N = 5e5 + 3, MOD = 998244353;

struct Edge {
  int x, c;
};

int n, m, ans, fac, f[N], cnt[N], g[N], p[N], h[N];

vector<Edge> G[N];

void S (int x, int fa) {
  for (auto to : G[x]) {
    if (to.x ^ fa) {
      S (to.x, x);
      h[x] += cnt[x] * cnt[to.x];
      cnt[x] += cnt[to.x];
      f[x] += f[to.x] + to.c * cnt[to.x];
    }
  }
}

void DP (int x, int fa) {
  for (auto to : G[x]) {
    if (to.x ^ fa) {
      g[to.x] = g[x] + to.c * (m - 2 * cnt[to.x]);
      DP (to.x, x);
    }
  }
}

int pw (int x, int y) {
  int res = 1;
  for (; y; y >>= 1) {
    if (y & 1) {
      res = res * x % MOD;
    }
    x = x * x % MOD;
  }
  return res;
}

main () {
  freopen ("sakuya.in", "r", stdin);
  freopen ("sakuya.out", "w", stdout);
  ios :: sync_with_stdio (0), cin.tie (0);
  cin >> n >> m, fac = 1;
  for (int i = 1, x, y, c; i < n; ++i) {
    cin >> x >> y >> c;
    G[x].push_back ({y, c});
    G[y].push_back ({x, c});
  }
  for (int i = 1, x; i <= m; ++i) {
    cin >> x, cnt[x] = p[x] = 1, fac = fac * i % MOD;
  }
  S (1, 0), g[1] = f[1], DP (1, 0);
  for (int i = 1; i <= n; ++i) {
    ans += p[i] * g[i];
  }
  cout << ans << '\n';
  int q; cin >> q;
  for (int x, k; q--; ) {
    cin >> x >> k;
    if (p[x]) {
	  ans += (cnt[x] - 1) * (m - cnt[x]) * k * 4; // x -> h -> fa
      ans += (h[x] - cnt[x] + 1) * 4; // x -> h -> y
      ans += (m - 1) * k * 2; // h -> y
    } else {
      ans += k * h[x] * 4; // x -> h -> y
      ans += cnt[x] * (m - cnt[x]) * k * 4;
    }
    cout << ans * pw (fac, MOD - 2) % MOD * (m - 1) % MOD << '\n';
  }
  return 0 ^ 0;
}
