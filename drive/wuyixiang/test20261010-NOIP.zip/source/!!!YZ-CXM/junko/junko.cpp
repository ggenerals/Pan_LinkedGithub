#include <bits/stdc++.h>

using namespace std;

const int N = 1e5 + 3, INF = 1e9;

struct State {
  int f, s;
  bool operator < (const State &p) const {
    return f > p.f || f == p.f && s < p.s;
  }
} f[N], pre[N], suf[N], ie;

int n, m, op[N], v[N], K[N];
bool vis[N];

State chk (State x, State y) {
  return (x < y ? x : y);
}

State add (State u, int v) {
  return {u.f + 1, min (u.s, v)};
}

int main () {
  freopen ("1.in", "r", stdin);
//  freopen ("junko.out", "w", stdout);
  cin >> n >> m, ie = {-1, 0};
  State ans = ie;
  srand (time (0));
  for (int i = 1; i <= m; ++i) {
	  cin >> op[i] >> v[i] >> K[i];
  }
  for (int _ = 1; _ <= 114; ++_) {
    for (int i = 1; i <= n; ++i) {
	  f[i] = {0, INF}, vis[i] = 0;
	}
    for (int __ = 1; __ <= m; ++__) {
	  cout << __ << '\n';
	  int id = 1ll * rand () % m + 1;
      int opt = op[id], val = v[id], k = K[id];
      pre[0] = suf[k + 1] = ie;
      vector<int> vec, q; vec.push_back (0);
      for (int p = 1, x; p <= k; ++p) {
        cin >> x, vec.push_back (x);
        pre[p] = chk (pre[p - 1], add (f[x], val));
      }
      for (int p = k; p; --p) {
        suf[p] = chk (suf[p + 1], add (f[vec[p]], val));
      }
      for (int p = 1, x; p <= k; ++p) {
        cin >> x, q.push_back (x);
      }
      if (!(opt - 1)) {
        for (int i = 0; i < k; ++i) {
		  if (vis[q[i]]) continue;
          f[q[i]] = chk (f[q[i]], pre[k]);
        }
      } else {
        for (int i = 0; i < k; ++i) {
		  if (vis[q[i]]) continue;
          f[q[i]] = chk (f[q[i]], chk (pre[i], suf[i + 2]));
        }
      }
      for (int i = 1; i <= n; ++i) {
        cout << f[i].f << " " << f[i].s << endl;
      }
    }
    for (int i = 1; i <= n; ++i) {
	  ans = chk (ans, f[i]);
    }
  }
  return cout << ans.f << " " << ans.s, 0 ^ 0;
}
