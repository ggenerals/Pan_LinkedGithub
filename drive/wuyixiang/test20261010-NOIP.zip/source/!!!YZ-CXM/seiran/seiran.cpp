#include <bits/stdc++.h>

using namespace std;
using ll = long long;
using pii = pair<int, int>;

const int N = 1e7 + 3, MOD = 998244353;

int n, m, arr[N << 1], g[N], ans, S, res, pw[N];
int *f[N], *nowcur;

int add (int x, int y) {
  return (x + y >= MOD ? x + y - MOD : x + y);
}

int main () {
  freopen ("seiran.in", "r", stdin);
  freopen ("seiran.out", "w", stdout);
  ios :: sync_with_stdio (0), cin.tie (0);
  cin >> n >> m, pw[0] = 1;
  for (int i = 1; i <= n; ++i) {
    pw[i] = add (pw[i - 1], pw[i - 1]);
  }
  nowcur = arr + n, f[0] = nowcur;
  f[0][0] = S = g[0] = 1;
  for (int i = 1; i <= n; ++i) {
    f[i] = f[i - 1] - 1, f[i][0] = S;
    S = add (S, S), S = add (S - f[i][m], MOD), g[i] = S;
    ans = add (ans, 1ll * f[i][m] * pw[n - i] % MOD);
  }
  for (int i = 1; i <= n; ++i) {
    if (n - (i + m - 1) >= 0) {
      res = add (res, 1ll * g[max (0, i - 2)] * g[max (0, n - i - m)] % MOD);
    }
  }
  return cout << ans << '\n' << res, 0 ^ 0;
}
