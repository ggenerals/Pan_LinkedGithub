#include<bits/stdc++.h>
using namespace std;
#define fre(x) freopen(x".in","r",stdin),freopen(x".out","w",stdout);
#define int long long
const int N=1000+5;
int n,m,dfn[N],scc[N],cnt,low[N],rt,tot,val[N],c[N],dp[N],in[N],dp2[N];
vector<int>nbr[N];
vector<int>nb[N];
map<pair<int,int>,int>mp;
bool vis[N],V[N];
int ans=0,anss;
stack<int>S;
void dfs(int x){
	dfn[x]=low[x]=++tot;
	vis[x]=1;
	S.push(x);
	for(int y:nbr[x]){
		if(!dfn[y]){
			dfs(y);
			low[x]=min(low[x],low[y]);
		}
		else if(vis[y])low[x]=min(low[x],dfn[y]);
	}
	if(dfn[x]==low[x]){
		cnt++;
		while(S.top()!=x){
			int y=S.top();
			S.pop();
			vis[y]=0;
			scc[y]=cnt;
		}
		int y=S.top();
		S.pop();
		vis[y]=0;
		scc[y]=cnt;
	}
}
int s[N][N],t[N][N];
int xf[N];
void init(){
	while(S.size())S.pop();
	tot=0;
	cnt=0;
	for(int i=1;i<=n;i++){
		dfn[i]=low[i]=0;
		vis[i]=0;
		scc[i]=0;
		val[i]=0;
		c[i]=1;
		nbr[i].clear(),nb[i].clear();
		in[i]=0;
		dp[i]=0;
		dp2[i]=0;
	}
	mp.clear();
}
struct ha{
	int op,vv,k;
}gunmu[N];
bool ch(int lol){
	init();
	ans=0;
	for(int i=1;i<=m;i++){
		int op=gunmu[i].op,vv=gunmu[i].vv,k=gunmu[i].k;
		if(vv>lol)continue;
		for(int j=1;j<=k;j++){
			for(int jj=1;jj<=k;jj++){
				if(op==2&&j==jj)continue;
				nbr[s[i][j]].push_back(t[i][jj]);
			}
		}
//		cout<<i<<" "<<m<<"\n";
	}
	for(int i=1;i<=n;i++)c[i]=1;
//	for(int i=1;i<=m;i++){
//		int x,y;
//		cin>>x>>y;
//		nbr[x].push_back(y);
//	}
	for(int i=1;i<=n;i++)
		if(!dfn[i])
			dfs(i);
	for(int i=1;i<=n;i++)
		val[scc[i]]+=c[i];
	for(int i=1;i<=n;i++)
		for(int j:nbr[i])	
			if(scc[i]!=scc[j]&&!mp[{i,j}]){
				mp[{i,j}]=1;
				nb[scc[i]].push_back(scc[j]);
				in[scc[j]]--;
			}
	for(int i=cnt;i>=1;i--)dp[i]=val[i];
	for(int i=cnt;i>=1;i--){
		for(int j:nb[i]){
			dp[j]=max(dp[j],dp[i]+val[j]);
		}
	}
	for(int i=1;i<=cnt;i++){
		ans=max(ans,dp[i]);
	}
	return ans==anss;
}
signed main(){
	fre("junko");
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int op,vv,k;
		cin>>op>>vv>>k;
		gunmu[i]={op,vv,k};
		for(int j=1;j<=k;j++){
			cin>>s[i][j];
		}
		for(int j=1;j<=k;j++){
			cin>>t[i][j];
		}
		for(int j=1;j<=k;j++){
			for(int jj=1;jj<=k;jj++){
				if(op==2&&j==jj)continue;
				nbr[s[i][j]].push_back(t[i][jj]);
			}
		}
//		cout<<i<<" "<<m<<"\n";
	}
	for(int i=1;i<=n;i++)c[i]=1;
//	for(int i=1;i<=m;i++){
//		int x,y;
//		cin>>x>>y;
//		nbr[x].push_back(y);
//	}
	for(int i=1;i<=n;i++)
		if(!dfn[i])
			dfs(i);
	for(int i=1;i<=n;i++)
		val[scc[i]]+=c[i];
	for(int i=1;i<=n;i++)
		for(int j:nbr[i])	
			if(scc[i]!=scc[j]&&!mp[{i,j}]){
				mp[{i,j}]=1;
				nb[scc[i]].push_back(scc[j]);
				in[scc[j]]--;
			}
	for(int i=cnt;i>=1;i--)dp[i]=val[i];
	for(int i=cnt;i>=1;i--){
		for(int j:nb[i]){
			dp[j]=max(dp[j],dp[i]+val[j]);
		}
	}
	for(int i=1;i<=cnt;i++){
		ans=max(ans,dp[i]);
	}
	cout<<ans<<" ";
	anss=ans;
	int l=-1,r=1e9+1;
	while(l+1<r){
		int mid=(l+r)/2;
//		cout<<l<<" "<<r<<"\n";
		if(ch(mid))r=mid;
		else l=mid;
	}
	cout<<r;
	return 0;
}
