#include<bits/stdc++.h>
#define int long long
#define fre(x) freopen(x".in","r",stdin),freopen(x".out","w",stdout);
using namespace std;
const int N=2e6+5,mod=998244353;
int n,m,dp[N],pre[N];
//到第 i 位，末尾为0/1且合法
int ksm(int x,int y){
	int X=1;
	while(y){
		if(y&1)X=X*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return X;
}
int a1=0,a2=0,v[N],ans=0;
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	fre("seiran");
	cin>>n>>m;
	dp[0]=1;
	pre[0]=1;
	for(int i=1;i<=n;i++){
		dp[i]+=dp[i-1];
		dp[i]%=mod;
		pre[i]=(pre[i-1]+dp[i])%mod;
		// if(i-m+1>=1)dp[i][1]+=pre[i-1]-pre[i-m]+mod;
		// else dp[i][1]+=pre[i-1];
		// dp[i][1]%=mod;
		if(i-m+1>=1){
			dp[i]+=(pre[i-1]-pre[i-m]+mod)%mod;
			// continue;
		}
		else{
			dp[i]+=pre[i-1];
			dp[i]%=mod;
			// continue;
		}
		// cout<<dp[i]<<"\n";
		// for(int k=2;k<=m&&i-k+1>=0;k++){
			// int j=i-k+1;
			// dp[i][1]+=dp[j][0];
			// dp[i][1]%=mod;
			// cout<<"-->"<<j<<"\n";
		// }
		// pre[i]=(pre[i-1]+dp[i][0])%mod;
		// cout<<pre[i]<<" "<<dp[i][1]<<" "<<i-1<<" "<<i-m<<"\n";
		// cout<<" "<<dp[i][0]<<" "<<dp[i][1]<<"\n";
	}
	cout<<(ksm(2,n)-(dp[n])+mod)%mod<<"\n";
	if(m==n){
		cout<<"1";
		return 0;
	}
	n-=m;
	ans+=dp[n-1]*2;
	for(int i=2;i<=n;i++){
		// cout<<i-1<<" "<<n-i<<"\n";
		ans+=dp[i-2]*dp[n-i]%mod;
		ans%=mod;
	}
	cout<<ans;
	// for(int )
	return 0;
}