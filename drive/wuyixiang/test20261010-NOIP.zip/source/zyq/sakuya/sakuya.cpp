#include<bits/stdc++.h>
#define int long long
#define fre(x) freopen(x".in","r",stdin),freopen(x".out","w",stdout);
using namespace std;
const int N=5e5+5,mod=998244353;
int n,m,v[N],num[N];
struct nn{
	int to,val,id;
};
vector<nn>nbr[N];
int siz[N],ans=0;
void dfs(int x,int fa){
	// cout<<x<<" "<<fa<<"\n";
	siz[x]=v[x];
	for(auto i:nbr[x]){
		int y=i.to,v=i.val,id=i.id;
		if(y==fa)continue;
		dfs(y,x);
		num[id]=(siz[y])*(m-siz[y])%mod;
		siz[x]+=siz[y];
	}
}
int ksm(int x,int y){
	int X=1;
	while(y){
		if(y&1)X=X*x%mod;
		x=x*x%mod;
		y>>=1;
	}
	return X;
}
struct edge{
	int u,v,w;
}e[N];
int cnt[N];
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	fre("sakuya");
	cin>>n>>m;
	for(int i=1;i<n;i++){
		int u,v,w;
		cin>>u>>v>>w;
		nbr[u].push_back({v,w,i});
		nbr[v].push_back({u,w,i});
		e[i]={u,v,w};
	}
	for(int i=1;i<=m;i++){
		int x;
		cin>>x;
		v[x]=1;
	}
	dfs(1,0);
	for(int i=1;i<n;i++){
		ans+=num[i]*e[i].w%mod;
		ans%=mod;
		(cnt[e[i].u]+=num[i])%=mod;
		(cnt[e[i].v]+=num[i])%=mod;
	}
	// cout<<ans<<"\n";
	// int jc=1;
	// for(int i=1;i<=m-1;i++)jc=jc*i%mod;
	int q;
	cin>>q;
	while(q--){
		int x,k;
		cin>>x>>k;
		ans+=cnt[x]*k;
		ans%=mod;
		int lol=ksm(m*(m-1)%mod,mod-2);
		cout<<ans*2%mod*(m-1)%mod*lol%mod<<"\n";
	}
	return 0;
}