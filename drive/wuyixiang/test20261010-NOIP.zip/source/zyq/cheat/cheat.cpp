#include<bits/stdc++.h>
#define int long long
#define fre(x) freopen(x".in","r",stdin),freopen(x".out","w",stdout);
using namespace std;
const int N=5e5+5,mod=998244353,inf=1e9;
int n,m,l[N],r[N],dis[N];
bool vis[N],v[N];
vector<int>nb[N];
vector<pair<int,int> >nbr[N];
void dij(int s){
	priority_queue<pair<int,int> >q;
	fill(dis+1,dis+1+n,inf);
	fill(vis+1,vis+1+n,0);
	dis[s]=0;
	q.push({0,s});
	while(q.size()){
		int x=q.top().second;
		q.pop();
		if(vis[x])continue;
		vis[x]=1;
		// cout<<x<<" "<<dis[x]<<"\n";
		for(auto i:nbr[x]){
			int y=i.first,id=i.second;
			if(v[id])continue;
			if(dis[y]>dis[x]+1){
				dis[y]=dis[x]+1;
				q.push({-dis[y],y});
			}
		}
		for(int y:nb[x]){
			if(dis[y]>dis[x]){
				dis[y]=dis[x];
				q.push({-dis[y],y});
			}
		}
	}
}
struct nn{
	int id,s,t,ii;
}q[N];
bool cmp(nn x,nn y){
	if(x.s==y.s)return x.id<y.id;
	return x.s<y.s;
}
int ans[N];
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	fre("cheat");
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		cin>>l[i]>>r[i];
		nbr[l[i]].push_back({r[i],i});
	}
	for(int i=n;i>=2;i--){
		nb[i].push_back(i-1);
	}
	int T;
	cin>>T;
	for(int i=1;i<=T;i++){
		cin>>q[i].id>>q[i].s>>q[i].t;
		q[i].ii=i;
		// v[q[i].id]=1;
		// dij(q[i].s);
		// cout<<dis[q[i].t]<<"\n";
		// v[q[i].id]=0;
	}
	sort(q+1,q+1+T,cmp);
	for(int i=1;i<=T;i++){
		if(i!=1&&q[i].s==q[i-1].s&&q[i].id==q[i-1].id){
			ans[q[i].ii]=dis[q[i].t];
			continue;
		}
		v[q[i].id]=1;
		dij(q[i].s);
		// cout<<dis[q[i].t]<<"\n";
		ans[q[i].ii]=dis[q[i].t];
		v[q[i].id]=0;
	}
	for(int i=1;i<=T;i++){
		if(ans[i]>=inf)cout<<"-1\n";
		else cout<<ans[i]<<"\n";
	}
	return 0;
}
