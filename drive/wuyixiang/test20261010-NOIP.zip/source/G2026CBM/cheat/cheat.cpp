#include<bits/stdc++.h>
#define int long long 
using namespace std;
int n,m,q;
const int N=2e5+5;
struct node
{
	int v,w;
};
vector<node> ed[N];
int dis[N];
bool vis[N];
#define inf 1e18
int idx,s,t;
deque<int> dq;
int l[N],r[N];
void bfs(int s)
{
	for(int i=1;i<=n;i++) vis[i]=0;
	for(int i=1;i<=n;i++) dis[i]=inf;
	dis[s]=0;
	dq.push_back(s);
	while(dq.size())
	{
		int u=dq.front();
		// cout<<u<<'\n';
		dq.pop_front();
		if(vis[u]) continue;
		vis[u]=1;
		for(auto i:ed[u])
		{
			int v=i.v,w=i.w;
			if(dis[u]+w<dis[v])
			{
				dis[v]=dis[u]+w;
				if(vis[v]) continue;
				if(w) dq.push_back(v);
				else dq.push_front(v);
			}
		}
	}
}
signed main()
{
	freopen("cheat.in","r",stdin);
	freopen("cheat.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	cin>>n>>m;
	for(int i=2;i<=n;i++)
		ed[i].push_back({i-1,0});
	for(int i=1;i<=m;i++)
	{
		cin>>l[i]>>r[i];
		ed[l[i]].push_back({r[i],1});
	}
	cin>>q;
	while(q--)
	{
		cin>>idx>>s>>t;
		int org=0;
		for(int i=0;i<ed[l[idx]].size();i++)
			if(ed[l[idx]][i].v==r[idx])
			{
				org=i;
				ed[l[idx]][i]={l[idx]-1,0};
				break;
			}
		bfs(s);
		if(dis[t]==inf) cout<<-1<<'\n';
		else cout<<dis[t]<<'\n';
		ed[l[idx]][org]={r[idx],1};
	}
	return 0;
}