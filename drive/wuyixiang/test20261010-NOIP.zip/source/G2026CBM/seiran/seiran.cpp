#include<bits/stdc++.h>
#define int long long 
using namespace std;
int n,k;
const int N=1e7+5;
const int mod=998244353;
int f[N],sum[N],pw[N];
signed main()
{
	freopen("seiran.in","r",stdin);
	freopen("seiran.out","w",stdout);
	cin>>n>>k;
	pw[0]=1;
	sum[0]=1;
	if(n==k)
	{
		cout<<1<<'\n'<<1<<'\n';
		exit(0);
	}
	for(int i=1;i<=n;i++)
	{
		pw[i]=pw[i-1]*2%mod;
		if(i<k) f[i]=pw[i];
		else
			f[i]=((sum[i-1]-sum[i-k-1])%mod+mod)%mod;
		sum[i]=(sum[i-1]+f[i])%mod;
		// cout<<f[i]<<' ';
	}
	cout<<((pw[n]-f[n])%mod+mod)%mod<<'\n';
	int ans=0;
	f[0]=1;
	for(int i=1;i+k-1<=n;i++)
	{
		int bs1=1,bs2=1;
		if(i>1) bs1=f[i-2];
		if(i+k-1<n) bs2=f[n-(i+k-1)-1];
		ans+=bs1*bs2%mod;
		// cout<<bs1<<','<<bs2<<'\n';
		ans%=mod;
	}
	cout<<ans<<'\n';
	return 0;
}