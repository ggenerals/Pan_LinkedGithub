#include<bits/stdc++.h>
#define int long long 
using namespace std;
int n,m;
const int N=5e5+5;
int u,v,w;
struct node
{
	int v,w;
};
vector<node> ed[N];
int q,x,k;
int ans,siz[N],val[N],wu[N];
const int mod=998244353;
int qpow(int x,int k)
{
	int ans=1,bs=x;
	while(k)
	{
		if(k&1) ans=ans*bs%mod;
		k>>=1;
		bs=bs*bs%mod;
	}
	return ans;
}
int niw;
void dfs(int u,int fa,int wal)
{
	// siz[u]=1;
	for(auto i:ed[u])
	{
		int v=i.v,w=i.w;
		if(v==fa) continue;
		dfs(v,u,w);
		siz[u]+=siz[v];
	}
	wu[u]=siz[u]*(m-siz[u])*2%mod*niw%mod;//父边单个贡献
	ans=(ans+wu[u]*wal%mod)%mod;
	// cout<<ans<<'\n';
}
void dfs2(int u,int fa)
{
	val[u]=wu[u];
	for(auto i:ed[u])
	{
		int v=i.v;
		if(v==fa) continue;
		dfs2(v,u);
		val[u]+=wu[v];
		val[u]%=mod;
	}
}
int a[N];
signed main()
{
	freopen("sakuya.in","r",stdin);
	freopen("sakuya.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	cin>>n>>m;
	niw=qpow(m,mod-2);
	for(int i=1;i<n;i++)
	{
		cin>>u>>v>>w;
		ed[u].push_back({v,w});
		ed[v].push_back({u,w});
	}
	for(int i=1;i<=m;i++)
		cin>>a[i],siz[a[i]]=1;
	dfs(1,0,0);
	dfs2(1,0);
	// for(int i=1;i<=n;i++)
	// 	cout<<wu[i]<<','<<val[i]<<'\n';
	// cout<<ans<<'\n';
	cin>>q;
	while(q--)
	{
		cin>>x>>k;
		ans=(ans+val[x]*k%mod)%mod;
		cout<<ans<<'\n';
	}
	return 0;
}