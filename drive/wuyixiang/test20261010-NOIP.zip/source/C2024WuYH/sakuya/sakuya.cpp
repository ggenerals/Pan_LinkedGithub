#include<bits/stdc++.h>
using namespace std;
#define int long long
#define mod 998244353
const int N=5e5+10;
int siz[N],dis[N],hg[N],n,m,xf9178,pw[N],ans,base;
struct node{
	int id,to,w;
};
vector<node>q[N];
void dfs(int x,int fa)
{
	for(int i=0;i<q[x].size();i++)
	{
		int to=q[x][i].to,w=q[x][i].w,id=q[x][i].id;
		if(to==fa)
			continue;
		dfs(to,x);
		siz[x]=siz[x]+siz[to];
		ans=(ans+siz[to]*(m-siz[to])%mod*pw[m-1]%mod*w%mod*2%mod)%mod;
		dis[id]=siz[to]*(m-siz[to])%mod*pw[m-1]%mod*2%mod;
	}
}
int qpow(int x,int y)
{
	if(y==0)
		return 1;
	int dis=qpow(x,y/2);
	dis=dis*dis%mod;
	if(y&1)
		dis=dis*x%mod;
	return dis;
}
signed main()
{
	freopen("sakura.in","r",stdin);
	freopen("sakura.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n>>m;
	for(int i=1;i<n;i++)
	{
		int x,y,w;
		cin>>x>>y>>w;
		q[x].push_back({i,y,w});
		q[y].push_back({i,x,w});
	}
	pw[0]=1;
	for(int i=1;i<=m;i++)
		pw[i]=pw[i-1]*i%mod;
	base=qpow(pw[m],mod-2);
	for(int i=1;i<=m;i++)
	{
		int x;
		cin>>x;
		siz[x]++;
	}
	dfs(1,0);
	for(int i=1;i<=n;i++)
		for(int j=0;j<q[i].size();j++)
			hg[i]=(hg[i]+dis[q[i][j].id])%mod;
	cin>>xf9178;
	while(xf9178--)
	{
		int x,y;
		cin>>x>>y;
		ans=(ans+hg[x]*y%mod)%mod;
		cout<<ans*base%mod<<"\n";
	}
	return 0;
}
