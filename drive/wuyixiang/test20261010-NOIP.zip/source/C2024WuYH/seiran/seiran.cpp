#include<bits/stdc++.h>
using namespace std;
#define int long long
#define mod 998244353
const int N=1e7+10;
int a[N],dp[N],n,m,f[N][2],cnt;
signed main()
{
	freopen("seiran.in","r",stdin);
	freopen("seiran.out","w",stdout);
	cin>>n>>m;
	a[0]=1;
	for(int i=1;i<=n;i++)
		a[i]=a[i-1]*2%mod;
	for(int i=m;i<=n;i++)
	{
		int hg=1;
		if(i-m-1>=0)
			hg=(a[i-m-1]-dp[i-m-1]+mod)%mod;
		dp[i]=(dp[i-1]*2%mod+hg)%mod;
		f[i][0]=(f[i-1][0]+f[i-1][1])%mod;
		f[i][1]=(cnt+hg)%mod;
		cnt=(cnt+f[i][0])%mod;
		cnt=(cnt-f[i-m+1][0]+mod)%mod;
	}
	cout<<dp[n]<<"\n"<<(f[n][0]+f[n][1])%mod;
	return 0;
}
