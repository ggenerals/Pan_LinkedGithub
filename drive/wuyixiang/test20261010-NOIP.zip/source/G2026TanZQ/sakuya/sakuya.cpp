#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=500005,p=998244353,inv2=499122177;
inline int qpow(int a,int b){int x=1,y=a;while(b){if(b&1)x=x*y%p;y=y*y%p;b>>=1;}return x;}
int n,m,q,ans=0,dis1[N],sum1[N],tag[N],summ[N],sum2[N];
struct node{int x,y;};
vector<node>e[N];
void dfs1(int x,int f)
	{
	sum1[x]=tag[x];
	for(int i=0;i<e[x].size();i++)
		{
		node d=e[x][i];
		if(d.x==f)continue;
		dfs1(d.x,x);
		sum1[x]+=sum1[d.x];
		dis1[x]=(dis1[x]+dis1[d.x]+d.y*sum1[d.x])%p;
		}
	}
void dfs2(int x,int f,int dw,int sw)
	{
	summ[x]=sw;sum2[x]=sw*sw;
	int dis2=dw+dis1[x];
	for(int i=0;i<e[x].size();i++)
		{
		node d=e[x][i];
		if(d.x==f)continue;
		dfs2(d.x,x,(dw+dis1[x]-dis1[d.x]+(m-2*sum1[d.x])*d.y)%p,sw+sum1[x]-sum1[d.x]);
		summ[x]+=sum1[d.x];sum2[x]+=sum1[d.x]*sum1[d.x];
		}
	//cout<<x<<' '<<summ[x]<<' '<<sum2[x]<<'\n';
	if(tag[x])ans=(ans+dis2)%p;
	}
signed main()
	{
	freopen("sakuya.in","r",stdin);
	freopen("sakuya.out","w",stdout);
	ios::sync_with_stdio(0);cin.tie(0);
	cin>>n>>m;int invm=qpow(m,p-2);
	for(int i=1;i<n;i++)
		{
		int u,v,w;cin>>u>>v>>w;
		e[u].push_back({v,w});
		e[v].push_back({u,w});
		}
	for(int i=1;i<=m;i++){int x;cin>>x;tag[x]=1;}
	dfs1(1,0);dfs2(1,0,0,0);
	int q;cin>>q;//cout<<ans*invm%p<<' '<<ans<<'\n';
	while(q--)
		{
		int x,k;cin>>x>>k;
		ans=(ans+(summ[x]*(summ[x]+tag[x])-sum2[x])%p*2*k)%p;
		cout<<ans*invm%p<<'\n';
		}
	return 0;
	}
