#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=10000005,p=998244353;
inline int qpow(int a,int b){int x=1,y=a;while(b){if(b&1)x=x*y%p;y=y*y%p;b>>=1;}return x;}
int n,m,dp[N],sum[N];
signed main()
	{
	freopen("seiran.in","r",stdin);
	freopen("seiran.out","w",stdout);
	ios::sync_with_stdio(0);cin.tie(0);
	cin>>n>>m;dp[0]=sum[0]=1;
	for(int i=1;i<=m;i++){dp[i]=dp[i-1]*2%p;sum[i]=(sum[i-1]+dp[i])%p;}
	dp[m]=(dp[m]+p-1)%p;sum[m]=(sum[m]+p-1)%p;
	for(int i=m+1;i<=n;i++){dp[i]=(sum[i-1]-sum[i-m-1]+p)%p;sum[i]=(sum[i-1]+dp[i])%p;}
	cout<<(qpow(2,n)-dp[n]+p)%p<<'\n';
	if(n==m){cout<<1;return 0;}
	int ans=0;
	for(int i=0;i<=n-m-2;i++)
		{
		ans=(ans+dp[i]*dp[n-m-2-i])%p;
		}
	cout<<(ans+dp[n-m-1]*2)%p;
	return 0;
	}
