#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=500005;
int n,m,vis[N],fa[N],siz[N],maxi=0;
struct node{int op,val,k;vector<int>e;}E[N];
int cmp(node a,node b){return a.val<b.val;}
int find(int x){return (x==fa[x]?x:fa[x]=find(fa[x]));}
void merge(int x,int y)
	{
	x=find(x);y=find(y);
	if(x==y)return;
	siz[x]+=siz[y];fa[y]=x;
	maxi=max(maxi,siz[x]);
	}
signed main()
	{
	freopen("junko.in","r",stdin);
	freopen("junko.out","w",stdout);
	ios::sync_with_stdio(0);cin.tie(0);
	cin>>n>>m;for(int i=1;i<=n;i++)fa[i]=i,siz[i]=1;
	for(int i=1;i<=m;i++)
		{
		cin>>E[i].op>>E[i].val>>E[i].k;
		for(int j=1;j<=2*E[i].k;j++)
			{
			int x;cin>>x;
			E[i].e.push_back(x);
			}
		}
	sort(E+1,E+m+1,cmp);int max2=0,maxw=0;
	for(int i=1;i<=m;i++)
		{
		if(E[i].op==2&&E[i].k<=2)
			{
			if(E[i].k==1)continue;
			merge(E[i].e[0],E[i].e[3]);
			merge(E[i].e[1],E[i].e[2]);
			continue;
			}
		for(int j=1;j<2*E[i].k;j++)
			{
			int x=E[i].e[j],y=E[i].e[0];
			merge(x,y);
			}
		if(maxi>max2){max2=maxi;maxw=E[i].val;}
		}
	cout<<max2<<' '<<maxw<<'\n';
	return 0;
	}
