
    {
        int cnt=0;
        FOR(i,0,n-1)if((s&(1<<i))){++cnt;if(cnt==m){++ans;break;}}
        else cnt=0;
    }