#include<bits/stdc++.h>
using namespace std;
#define int long long
using ll=long long;
namespace florr
{
    #define meow ios_base::sync_with_stdio(false);cin.tie(0)
    #define FOR(i,l,r) for(int i=l;i<=r;++i)
    #define ROF(i,r,l) for(int i=r;i>=l;--i)
    #define FORK(i,l,r,k) for(int i=l;i<=r;i+=k)
    #define ROFK(i,r,l,k) for(int i=r;i>=l;i-=k)
    #define REP(i,st,ed,nxt) for(int i=st;i!=ed;i=nxt)
    #define file(s) freopen(s".in","r",stdin),freopen(s".out","w",stdout);
    const int inf=0x3f3f3f3f;
    const long long infll=0x3f3f3f3f3f3f3f3fll;
    const __int128 infi128=(__int128(1)<<126);
    __int128 abs(__int128 x){return x<0?-x:x;}
    template<typename T=int>T chkmi(T &x,T y){return x=(x<y?x:y);}
    template<typename T=int>T chkmx(T &x,T y){return x=(x>y?x:y);}
}//namespace florr
using namespace florr;
constexpr int N=1e7+5,mod=998244353;
int qpow(int a,int b,int mod=::mod)
{
    int res=1;
    for(;b;b>>=1,a=a*a%mod)if(b&1)res=res*a%mod;
    return res;
}
//f: 前 i 个数字，除了区间 [i-m+1,i]，没有其他区间满足条件的方案数
//g：前 i 个数字，不满足条件，但是末尾为 0 的方案数
//h：前 i 个数字，不满足条件，末尾为 1 方案数
int dp[N][2],pw[N];
void init()
{
    
}
void solve()
{
    int n,m,ans1=0,ans2=0,sum=0;
    cin>>n>>m;
    dp[0][0]=1;
    pw[0]=1;
    FOR(i,1,n)pw[i]=pw[i-1]*2%mod;
    FOR(i,1,n)
    {
        if(i>=m)dp[i][1]=dp[i-m][0];
        dp[i][0]=(pw[i-1]-sum+mod)%mod;
        if(i>=m)
        {
            ans1=(ans1+dp[i][1]*pw[i-1]%mod)%mod;
            sum=(sum*2%mod+dp[i][1])%mod;
        }
    }
    FOR(i,1,n)if(i>=m)
        ans2=(ans2+dp[i-m][0]*dp[n-i][0]%mod)%mod;
    cout<<ans1<<'\n';
    cout<<ans2<<'\n';
}
signed main()
{
    double start_time=clock();
    file("seiran");
    meow;
    signed T=1;
    // cin>>T;
    init();
    FOR(i,1,T)solve();
    double end_time=clock();
    clog<<"used time:"<<(end_time-start_time)/CLOCKS_PER_SEC<<"s\n";
}