/*
zorr! zorr! zorr! the victory is for zorr!

zorr! zorr! zorr! zorr! zorr!


*/

#include<bits/stdc++.h>
using namespace std;
#define int long long
using ll=long long;
namespace florr
{
    #define meow ios_base::sync_with_stdio(false);cin.tie(0)
    #define FOR(i,l,r) for(int i=l;i<=r;++i)
    #define ROF(i,r,l) for(int i=r;i>=l;--i)
    #define FORK(i,l,r,k) for(int i=l;i<=r;i+=k)
    #define ROFK(i,r,l,k) for(int i=r;i>=l;i-=k)
    #define REP(i,st,ed,nxt) for(int i=st;i!=ed;i=nxt)
    #define file(s) freopen(s".in","r",stdin),freopen(s".out","w",stdout);
    const int inf=0x3f3f3f3f;
    const long long infll=0x3f3f3f3f3f3f3f3fll;
    const __int128 infi128=(__int128(1)<<126);
    __int128 abs(__int128 x){return x<0?-x:x;}
    template<typename T=int>T chkmi(T &x,T y){return x=(x<y?x:y);}
    template<typename T=int>T chkmx(T &x,T y){return x=(x>y?x:y);}
}//namespace florr
using namespace florr;
constexpr int N=1e5+5;
vector<tuple<int,int,int> >edge[N<<2];
int S[N],T[N];
void init()
{
    
}
void solve()
{
    int n,m;
    cin>>n>>m;
    int tot=n;
    FOR(i,1,m)
    {
        int op,w,k;
        cin>>op>>w>>k;
        FOR(i,1,k)cin>>S[i];
        FOR(i,1,k)cin>>T[i];
        ++tot;
        FOR(i,1,k)edge[tot].emplace_back(T[i],w,1);
        if(op==1)FOR(i,1,k)edge[S[i]].emplace_back(tot,infll,0);
        else FOR(i,1,k)FOR(j,1,k)if(i!=j)
            edge[i].emplace_back(j,w,1);
    }
    cout<<"puck comes very fast\n";
}
signed main()
{
    double start_time=clock();
    file("junko");
    meow;
    signed T=1;
    //cin>>T;
    init();
    FOR(i,1,T)solve();
    double end_time=clock();
    clog<<"used time:"<<(end_time-start_time)/CLOCKS_PER_SEC<<"s";
}