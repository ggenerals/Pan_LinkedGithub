#include<bits/stdc++.h>
using namespace std;
#define int long long
using ll=long long;
namespace florr
{
    #define meow ios_base::sync_with_stdio(false);cin.tie(0)
    #define FOR(i,l,r) for(int i=l;i<=r;++i)
    #define ROF(i,r,l) for(int i=r;i>=l;--i)
    #define FORK(i,l,r,k) for(int i=l;i<=r;i+=k)
    #define ROFK(i,r,l,k) for(int i=r;i>=l;i-=k)
    #define REP(i,st,ed,nxt) for(int i=st;i!=ed;i=nxt)
    #define file(s) freopen(s".in","r",stdin),freopen(s".out","w",stdout);
    const int inf=0x3f3f3f3f;
    const long long infll=0x3f3f3f3f3f3f3f3fll;
    const __int128 infi128=(__int128(1)<<126);
    __int128 abs(__int128 x){return x<0?-x:x;}
    template<typename T=int>T chkmi(T &x,T y){return x=(x<y?x:y);}
    template<typename T=int>T chkmx(T &x,T y){return x=(x>y?x:y);}
}//namespace florr
using namespace florr;
constexpr int N=2e5+5;
vector<pair<int,int> >edge[N];
int dis[N];bool vis[N];
void init()
{
    
}
void solve()
{
    int n,m,q;
    cin>>n>>m;
    FOR(i,1,m)
    {
        int l,r;
        cin>>l>>r;
        edge[l].emplace_back(r,i);
    }
    ROF(i,n,2)edge[i].emplace_back(i-1,0);
    cin>>q;
    auto dijkstra=[&](int s,int id)
    {
        priority_queue<pair<int,int>,vector<pair<int,int> >,greater<pair<int,int> > >q;
        
        FOR(i,1,n)dis[i]=infll,vis[i]=0;
        q.emplace(dis[s]=0,s);
        while(!q.empty())
        {
            int u=q.top().second;q.pop();
            // cout<<u<<' ';
            if(vis[u])continue;
            vis[u]=1;
            for(auto [v,x]:edge[u])if(x!=id)
            {
                if(dis[u]+!!x<dis[v])
                {
                    dis[v]=dis[u]+!!x;
                    q.emplace(dis[v],v);
                }
            }
        }
    };
    while(q--)
    {
        int id,s,t;
        cin>>id>>s>>t;
        dijkstra(s,id);
        cout<<(dis[t]==infll?-1:dis[t])<<'\n';
    }
}
signed main()
{
    double start_time=clock();
    file("cheat");
    meow;
    signed T=1;
    //cin>>T;
    init();
    FOR(i,1,T)solve();
    double end_time=clock();
    clog<<"used time:"<<(end_time-start_time)/CLOCKS_PER_SEC<<"s";
}