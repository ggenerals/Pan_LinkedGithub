#include<bits/stdc++.h>
using namespace std;
#define int long long
using ll=long long;
namespace florr
{
    #define meow ios_base::sync_with_stdio(false);cin.tie(0)
    #define FOR(i,l,r) for(int i=l;i<=r;++i)
    #define ROF(i,r,l) for(int i=r;i>=l;--i)
    #define FORK(i,l,r,k) for(int i=l;i<=r;i+=k)
    #define ROFK(i,r,l,k) for(int i=r;i>=l;i-=k)
    #define REP(i,st,ed,nxt) for(int i=st;i!=ed;i=nxt)
    #define file(s) freopen(s".in","r",stdin),freopen(s".out","w",stdout);
    const int inf=0x3f3f3f3f;
    const long long infll=0x3f3f3f3f3f3f3f3fll;
    const __int128 infi128=(__int128(1)<<126);
    __int128 abs(__int128 x){return x<0?-x:x;}
    template<typename T=int>T chkmi(T &x,T y){return x=(x<y?x:y);}
    template<typename T=int>T chkmx(T &x,T y){return x=(x>y?x:y);}
}//namespace florr
using namespace florr;
constexpr int N=5e5+5,mod=998244353;
int n,m;
int fac[N],inv[N],cnt[N],sum[N],a[N],sz[N],ans;
vector<pair<int,int> >edge[N];
// int dp[N];
int qpow(int a,int b,int mod=::mod)
{
    int res=1;
    for(;b;b>>=1,a=a*a%mod)if(b&1)res=res*a%mod;
    return res;
}
void dfs(int u,int fa)
{
    for(auto [v,w]:edge[u])if(v!=fa)
    {
        dfs(v,u);
        sum[u]=(sum[u]+cnt[v])%mod;
        ans=(ans+w*cnt[v]%mod)%mod;
        sz[u]+=sz[v];
    }
    cnt[u]=2*sz[u]%mod*(m-sz[u])%mod*fac[m-1]%mod;
}
void init()
{
    
}
void solve()
{
    cin>>n>>m;
    fac[0]=1;
    FOR(i,1,m)fac[i]=fac[i-1]*i%mod;
    inv[m]=qpow(fac[m],mod-2);
    ROF(i,m-1,0)inv[i]=inv[i+1]*(i+1)%mod;
    FOR(i,1,n-1)
    {
        int u,v,w;
        cin>>u>>v>>w;
        edge[u].emplace_back(v,w);
        edge[v].emplace_back(u,w);
    }
    FOR(i,1,m)cin>>a[i],sz[a[i]]=1;
    dfs(1,0);
    int q;cin>>q;
    while(q--)
    {
        int u,k;cin>>u>>k;
        // cout<<sum[u]<<' '<<cnt[u]<<'\n';
        ans=(ans+(sum[u]+(u!=1)*cnt[u])%mod*k%mod)%mod;
        cout<<ans*inv[m]%mod<<'\n';
    }
}
signed main()
{
    double start_time=clock();
    file("sakuya");
    meow;
    signed T=1;
    //cin>>T;
    init();
    FOR(i,1,T)solve();
    double end_time=clock();
    clog<<"used time:"<<(end_time-start_time)/CLOCKS_PER_SEC<<"s\n";
}