
    FOR(i,1,m)cin>>a[i],sz[a[i]]=1;