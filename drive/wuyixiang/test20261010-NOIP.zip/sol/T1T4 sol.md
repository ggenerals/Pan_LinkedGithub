

## 兔已着陆

计数题。

一看就是 dp，但不好直接设状态，所以先考虑找性质。

第一问：

发现任意一个满足条件的最终状态，它必然有一个长度为 $m$ 的全部是 $1$ 的字串，为了不重，我们枚举最左边的一个长度为 $m$ 的全部是 $1$ 的字串的左端点，设它为 $i$，这样可以保证你是不重的。

然后由于是最左边的一个，所以 $[1,i-1]$ 中，不存在一个连续有 $m$ 个 $1$ 的子区间，这种方案数待会处理，而 $[\min(i+m,n),n]$ 中可以随便选，这一段的方案数显然就是 $2^{n-\min(i+m,n)+1}$，两边乘起来就是 $i$ 的贡献了。

现在问题转换为了：求一个没有任何一个连续出 $m$ 个 $1$ 的前缀个数。

这个显然很好可以 dp 处理了。

设 $f_{i,j}$ 表示考虑 $i$ 个数的前缀，当前的后缀有 $j$ 个 $1$ 的方案数，明显就是个简单 dp：

$f_{i,j}=f_{i-1,j-1}\ (j\not = 0)$

$f_{i,j}=\sum\limits_{k=0}^{m-1} f_{i-1,k} (j=0)$

然后 $\sum\limits_{j=0}^{m-1} f_{i,j}$ 就是任何一个连续出 $m$ 个 $1$ 的前缀个数。

但这是 $O(n^2)$ 的，过不去。

你发先你要求的是 $\sum\limits_{j=0}^{m-1} f_{i,j}$，而这就是 $f_{i+1,0}$。所以可以设 $g_i=\sum\limits_{j=0}^{m-1} f_{i,j}$，然后手动模拟观察后可以发现，你可以直接转移 $g$，$g_i=\sum\limits_{j=\max(i-m-1,0)}^{i-1} g_j$ 并且可以前缀和优化，这样就做到了 $O(n)$。

考虑第二问，其实和第一问没什么区别。

依然枚举唯一的一段全都是 $1$ 的长度为 $m$ 的区间，然后你发现就是剩下两边的 $g$ 乘起来的方案数求和，你又做完了。

code：
```cpp
#include<bits/stdc++.h>
#define int long long
#define mod 998244353
using namespace std;
int quickpow(int a,int b){
	int ret=1;
	while(b){
		if(b&1) ret=ret*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return ret;
}
int n,m;
int f[10000001],S[10000001],P[10000001];
signed main(){
	cin>>n>>m;
	P[0]=1;
	for(int i=1;i<=n;i++){
		P[i]=P[i-1]*2%mod;
	}
	f[0]=S[0]=1;for(int i=1;i<m;i++) f[i]=f[i-1]*2%mod,S[i]=S[i-1]+f[i],S[i]%=mod;
	for(int i=m;i<=n;i++){
		f[i]=S[i-1]-S[i-1-m];f[i]=(f[i]+mod)%mod;
		S[i]=S[i-1]+f[i];S[i]%=mod;
	}
	int ans=0;
	for(int i=1;i<=n-m+1;i++){
		if(i==1) ans+=P[n-(i+m-1)];
		else ans+=f[i-2]*P[n-(i+m-1)]%mod;
		ans%=mod;
	}
	cout<<ans<<'\n';
	ans=0;
	for(int i=1;i<=n-m+1;i++){
		if(i==1) ans+=f[n-i-m];
		else if(i==n-m+1) ans+=f[i-2];
		else ans+=f[i-2]*f[n-i-m]%mod;
		ans%=mod;
	}
	cout<<ans;
}
```

## Pure Furies ～ 心之所在

首先考虑如果暴力建图怎么做，首先肯定要二分答案这个$Power$，然后发现可以缩点后拓扑排序，再 dp 计DAG上最长链即可，这一部分比较简单，可以获得 $20$ 分。

再考虑一下 $opt=1$，由于你对图进行了缩点，其实你只用保证图的连通分量一致即可，于是思考优化建图。对于一次建边，则我们建一个虚点 $x$ ，令 $x$ 的权值为 $0$，其他点为 $1$，于是可以使 $S_i\to x,x\to T_i(1\le i\le k)$。这样显然不影响强连通性，于是再套用上面的 $20$ 分做法即可得到 $45$ 分。

现在再思考 $opt=2$，这就很简单想了，看到约束条件可以直接想到前缀优化建图，然后就做完了。

那个 $val=0$ 是留给常数写的不好的做法。

```cpp
#include<bits/stdc++.h>
using namespace std;
int n,m;
struct edge{
	int from,to,val;
}e[8000001];int size,head[4000001];
void addedge(int x,int y,int z){
	e[++size].to=y,e[size].val=z;
	e[size].from=head[x],head[x]=size;
}
int a[4000001],b[4000001];
int vall[4000001];
int lsq[4000001],tot;
unordered_map<long long,int> ma;
int dfn[4000001],low[4000001],D,vis[4000001],s[4000001],top;
int k,val[4000001],col[4000001];
void tar(int now,int lim){
	dfn[now]=low[now]=++D;
	vis[now]=1;
	s[++top]=now;
	for(int i=head[now];i;i=e[i].from){
		if(e[i].val>lim) continue;
		int u=e[i].to;
		if(!dfn[u]){
			tar(u,lim);
			low[now]=min(low[now],low[u]);
		}
		else if(vis[u]){
			low[now]=min(low[now],dfn[u]);
		}
	}
	if(low[now]==dfn[now]){
		k++;
		while(s[top+1]!=now){
			col[s[top]]=k;
			val[k]+=vall[s[top]];
			vis[s[top]]=0;
			top--;
		}
	}
}
vector<int> E[4000001],E_[4000001];
int ru[4000001],f[4000001],id[4000001],T;
void topu(){
	T=0;
	queue<int> q;
	fill(vis+1,vis+1+k,0);
	fill(f+1,f+1+k,0);
	for(int i=1;i<=k;i++){
		if(!ru[i]){
			q.push(i);
			id[++T]=i;
		}
	}
	while(!q.empty()){
		int now=q.front();q.pop();
		vis[now]=1;
		for(int u:E[now]){
			if(vis[u]) continue;
			ru[u]--;
			if(!ru[u]){
				q.push(u);
				id[++T]=u;
			}
		}
	}
	for(int i=1;i<=k;i++){
		if(ru[i]){
			id[++T]=i;
		}
	}
}
void build(int lim){
	for(int i=1;i<=n;i++){
		E[i].clear(),E_[i].clear();
		dfn[i]=low[i]=val[i]=0;
		ru[i]=f[i]=id[i]=0;
	}k=top=0;
	for(int i=1;i<=n;i++){
		if(!dfn[i]) tar(i,lim);
	}
	for(int i=1;i<=n;i++){
		for(int v=head[i];v;v=e[v].from){
			if(e[v].val>lim) continue;
			int u=e[v].to;
			if(col[i]!=col[u]){
				E[col[i]].push_back(col[u]);
				E_[col[u]].push_back(col[i]);
				ru[col[u]]++;
			}
		}
	}
}
int dp(int lim){
	build(lim);
	topu();
	int ans=0;
	for(int i=1;i<=k;i++){
		f[id[i]]=val[id[i]];
		for(int u:E_[id[i]]){
			f[id[i]]=max(f[id[i]],val[id[i]]+f[u]);
		}
		ans=max(ans,f[id[i]]);
	}
	return ans;
}
int v1[1000001],v2[1000001];
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0); cout.tie(0); 
	cin>>n>>m;
	for(int i=1;i<=n;i++) vall[i]=1;
	while(m--){
		int op,V,K;
		cin>>op>>V>>K;
		lsq[++tot]=V;
		for(int i=1;i<=K;i++) cin>>a[i];
		for(int i=1;i<=K;i++) cin>>b[i];
		if(op==1){
			n++;
			for(int i=1;i<=K;i++){
				addedge(a[i],n,V);
				addedge(n,b[i],V);
			}
		}
		else{
			for(int i=1;i<=K;i++){
				v1[i-1]=++n,v2[i-1]=++n;
				addedge(a[i],v1[i-1],V);
				addedge(v2[i-1],b[i],V);
			}
			for(int i=1;i<K;i++){
				addedge(v1[i],v1[i-1],V);
				addedge(v1[i],b[i],V);
			}
			for(int i=0;i<K-1;i++){
				addedge(v2[i],v2[i+1],V);
				addedge(a[i+1],v2[i+1],V);
			}
		}
	}
	sort(lsq+1,lsq+1+tot);
	tot=unique(lsq+1,lsq+1+tot)-lsq-1;
	for(int i=1;i<=tot;i++){
		ma[lsq[i]]=i;
	}
	for(int i=1;i<=size;i++){
		e[i].val=ma[e[i].val];
	}
	int ans=dp(tot);
	int l=1,r=tot-1,pos=tot;
	while(l<=r){
		int mid=(l+r)>>1;
		if(dp(mid)==ans){
			r=mid-1;
			pos=mid;
		}
		else{
			l=mid+1;
		}
	}
	cout<<ans<<' '<<lsq[pos]<<'\n';
}
```
