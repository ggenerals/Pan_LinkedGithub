令 $f_i$ 表示现在在第 $i$ 格，跳到“往左走若干格后能跳到的最右侧的点”经过的挂的编号。

$g_i$ 表示现在在第 $i$ 格，跳到“往左走若干格后能跳到的次右侧的点（不严格）”经过的挂的编号。

每次查询时 ban 了一个挂，所以每次跳的边要么是 $f$ 要么是 $g$。只要先倍增跳 $f$，当要跳的 $f$ 边被 ban 了时就倍增跳 $g$ ，直到 $f$ 不再被 ban 然后就接着倍增跳 $f$ 即可。

```
#include<bits/stdc++.h>
using namespace std;
constexpr int N=500000;
int l[N+10],r[N+10],fa1[19][N+10],fa2[19][N+10];
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	int n,m;
	cin>>n>>m;
	int i,j;
	for(i=1;i<=n;++i) fa1[0][i]=fa2[0][i]=i;
	for(i=1;i<=m;++i){
		cin>>l[i]>>r[i];
		if(r[i]>fa1[0][l[i]]) fa2[0][l[i]]=fa1[0][l[i]],fa1[0][l[i]]=r[i];
		else fa2[0][l[i]]=max(fa2[0][l[i]],r[i]);
	}
	for(i=1;i<n;++i){
		if(fa1[0][i]>fa1[0][i+1]){
			fa2[0][i+1]=fa1[0][i+1];
			fa1[0][i+1]=max(fa1[0][i+1],fa1[0][i]);
			fa2[0][i+1]=max(fa2[0][i+1],fa2[0][i]);
		}
		else fa2[0][i+1]=max(fa2[0][i+1],fa1[0][i]);
	}
	for(i=1;i<19;++i){
		for(j=1;j<=n;++j) fa1[i][j]=fa1[i-1][fa1[i-1][j]],fa2[i][j]=fa2[i-1][fa2[i-1][j]];
	}
	int q;
	cin>>q;
	for(i=1;i<=q;++i){
		int id,s,t,L,R,ans=0;
		cin>>id>>s>>t;
		//skip1978
		L=l[id],R=r[id];
		for(j=18;j>=0;--j){
			if(fa1[j][s]<L&&fa1[j][s]<t) ans+=1<<j,s=fa1[j][s];
		}
		if(s<L&&s<t) s=fa1[0][s],++ans;
		if(s>=t){
			cout<<ans<<'\n';
			continue;
		}
		if(s<L){
			cout<<"-1\n";
			continue;
		}
		//skip2004
		for(j=18;j>=0;--j){
			if(fa2[j][s]>=t) continue;
			if(fa1[0][fa2[j][s]]==R){
				ans+=1<<j;
				s=fa2[j][s];
			}
		}
		if(s<t&&fa1[0][s]==R) s=fa2[0][s],++ans;
		if(s>=t){
			cout<<ans<<'\n';
			continue;
		}
		if(fa1[0][s]<=R){
			cout<<"-1\n";
			continue;
		}
		//skip1978
		for(j=18;j>=0;--j){
			if(!fa1[j][s]) continue;
			if(fa1[j][s]<t) s=fa1[j][s],ans+=1<<j;
		}
		if(s<t&&fa1[0][s]!=R) s=fa1[0][s],++ans;
		if(s<t) cout<<"-1\n";
		else cout<<ans<<'\n';
	}
	return 0;
}
```