## sakuya 题解

这题其实灵感来源于一次考试的题。

首先把期望转为算平均数，其实就是算 $\sum\limits_{i,j} d(a_i,a_j)$ 的值，因为两个点相邻的概率是一样的。

然后算这个东西可以考虑树形dp，直接暴力换根找到每个点的距离即可。

但这不太方便操作，所以提供另一种处理的思路。

记连接 $x,y$ 条边在 $\sum\limits_{i,j} d(a_i,a_j)$ 这个式子中被计过的边数为 $num_{x,y}$，那么一次操作对这个式子的修改是增加了 $k\sum\limits_{E(x,u)} num_{x,u}$ ，显然，预处理出 $num$ 后可以 $O(1)$ 计算。

那么树形dp处理的部分就是求出 $num$，我们这样考虑一条边，一条边可以把树分为两个部分，那么就是这两个部分的特殊点的个数乘积就是 $num$ 的值了，树形dp预处理子树中特殊点的个数即可。

具体细节自己处理吧。

这题，不难吧...

```cpp
#include<bits/stdc++.h>
#define int long long
#define mod 998244353
using namespace std;
int quickpow(int a,int b){
	int ret=1;
	while(b){
		if(b&1) ret=ret*a%mod;
		a=a*a%mod; 
		b>>=1;
	}
	return ret;
}
int inv(int x){
	return quickpow(x,mod-2);
}
int n,m,q;
struct edge{
	int from,to,val;
}e[2000001<<1];int head[2000001],size;
void addedge(int x,int y,int z){
	e[++size].to=y,e[size].val=z;
	e[size].from=head[x],head[x]=size;
}
int dep[2000001],p[2000001],f[2000001];
bool vis[2000001];
int tot; 
void dfs1(int now,int fa){
	if(vis[now]) p[now]++;
	dep[now]=dep[fa]+1;
	for(int i=head[now];i;i=e[i].from){
		int u=e[i].to;
		if(u==fa) continue;
		dfs1(u,now);
		p[now]+=p[u];
	}
}
int get(int x,int y){
	if(dep[x]>dep[y]) return p[x]*(m-p[x]);
	return p[y]*(m-p[y]);
}
int ans;
void dfs2(int now,int fa){
	for(int i=head[now];i;i=e[i].from){
		int u=e[i].to;
		f[now]+=get(now,u);
		f[now]%=mod;
		if(u==fa) continue;
		dfs2(u,now);
		ans+=e[i].val*get(now,u);
		ans%=mod;
	}
}
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n>>m;
	int times=inv(m)*2%mod;
	for(int i=1;i<n;i++){
		int x,y,z;
		cin>>x>>y>>z;
		addedge(x,y,z);
		addedge(y,x,z);
	}
	for(int i=1;i<=m;i++){
		int x;cin>>x;
		vis[x]=1;
	}
	dfs1(1,1);
	dfs2(1,1);
	cin>>q;
	while(q--){
		int x,k;cin>>x>>k;
		ans+=f[x]*k%mod;ans%=mod;
		cout<<ans*times%mod<<'\n';
	}
} 
```

## 
